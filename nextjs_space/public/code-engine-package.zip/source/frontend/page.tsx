'use client'

import { useState, useEffect, useCallback, useRef, useMemo } from 'react'

import { motion, AnimatePresence } from 'framer-motion'
import {
  Send,
  Loader2,
  Plus,
  Trash2,
  AlertTriangle,
  RefreshCw,
  Folder,
  Settings,
  Check,
  ChevronDown,
  ChevronUp,
  Shield,
  Sparkles,
  Eye,
  FolderTree,
  FileText,
  FolderOpen,
  Zap,
  Maximize2,
  Minimize2,
  ExternalLink,
  RotateCw,
  X,
} from 'lucide-react'
import Link from 'next/link'
import { TURBO_MODELS } from '@/lib/turbo-config'
import { useI18n } from '@/lib/i18n-context'

// ----------------------------------------------------------------------------
// CODE ENGINE — "Invisible IDE" (white minimalist UI)
// ----------------------------------------------------------------------------
// Aesthetic: pure white background, soft gray accents, capsule input,
// Activity Feed instead of chat bubbles, dual-pane layout (chat | preview).
// Code blocks and JSON envelopes are hidden by default.
// ----------------------------------------------------------------------------

const CODE_MODELS = TURBO_MODELS.filter((m) =>
  m.id.startsWith('anthropic/') ||
  m.id.startsWith('openai/') ||
  m.id.startsWith('deepseek/') ||
  m.id === 'google/gemini-3.1-pro-preview',
)

const DEFAULT_MODEL = 'anthropic/claude-sonnet-4.6'

interface CodeMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  status: 'pending' | 'streaming' | 'completed' | 'failed'
  error?: string | null
  createdAt: string
}

interface BridgeCommand {
  id: string
  sessionId: string
  messageId: string | null
  type: string
  payload: string
  status: 'pending' | 'approved' | 'rejected' | 'executing' | 'completed' | 'failed'
  result?: string | null
  error?: string | null
  streamOutput?: string | null
  requiresConfirmation: boolean
  createdAt: string
  completedAt?: string | null
}

interface CodeSession {
  id: string
  model: string
  title: string
  updatedAt: string
  _count?: { messages: number; commands: number }
}

interface BridgeStatus {
  online: boolean
  lastSeen?: string | null
}

/** Safely parse a payload/result that may be a JSON string or already an object */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function safeJsonParse<T = Record<string, any>>(val: unknown, fallback?: T): T {
  if (!val) return (fallback ?? {}) as T
  if (typeof val === 'object') return val as T
  try { return JSON.parse(val as string) } catch { return (fallback ?? {}) as T }
}

interface WorkspaceFile {
  path: string
  isDir: boolean
  size: number
}

interface WorkspaceData {
  indexed: boolean
  fileCount?: number
  totalSize?: number
  rootPath?: string
  lastScanAt?: string
  tree?: WorkspaceFile[]
}

interface FileChangeItem {
  id: string
  eventType: string
  filePath: string
  fileSize?: number
  isDir: boolean
  detectedAt: string
}

// ----------------------------------------------------------------------------
// Action metadata: human-friendly labels + soft icons
// ----------------------------------------------------------------------------
function getActionMeta(type: string, t: (key: string) => string) {
  switch (type) {
    case 'write_file':
      return { label: t('ce.action_write'), labelDone: t('ce.action_write_done'), emoji: '📄' }
    case 'read_file':
      return { label: t('ce.action_read'), labelDone: t('ce.action_read_done'), emoji: '📖' }
    case 'create_dir':
      return { label: t('ce.action_mkdir'), labelDone: t('ce.action_mkdir_done'), emoji: '📁' }
    case 'read_dir':
      return { label: t('ce.action_ls'), labelDone: t('ce.action_ls_done'), emoji: '🗂' }
    case 'open_path':
      return { label: t('ce.action_open'), labelDone: t('ce.action_open_done'), emoji: '↗' }
    case 'delete_file':
      return { label: t('ce.action_delete'), labelDone: t('ce.action_delete_done'), emoji: '🗑' }
    case 'execute_cmd':
      return { label: t('ce.action_exec'), labelDone: t('ce.action_exec_done'), emoji: '⚡' }
    default:
      return { label: type, labelDone: type, emoji: '•' }
  }
}

// StageMark replaced by numbered step indicators in ActivityRow

// ----------------------------------------------------------------------------
// Determine parent folder of a path (for "Abrir carpeta" button)
// ----------------------------------------------------------------------------
function parentDir(p: string | undefined): string {
  if (!p) return ''
  const parts = p.replace(/\\/g, '/').split('/').filter(Boolean)
  if (parts.length <= 1) return ''
  return parts.slice(0, -1).join('/')
}

function isHtmlPath(p: string | undefined): boolean {
  return !!p && /\.html?$/i.test(p)
}

// ----------------------------------------------------------------------------
// Single activity row — humanized command summary, no JSON, no terminal
// ----------------------------------------------------------------------------
function ActivityRow({
  command,
  index,
  total,
  onConfirm,
  onReject,
  onSelect,
  selected,
  onOpenPath,
  onPreviewHtml,
  t,
}: {
  command: BridgeCommand
  index: number
  total: number
  onConfirm: (id: string) => void
  onReject: (id: string) => void
  onSelect: (id: string) => void
  selected: boolean
  onOpenPath: (path: string) => void
  onPreviewHtml: (cmdId: string) => void
  t: (key: string) => string
}) {
  const meta = getActionMeta(command.type, t)
  let payload: { path?: string; command?: string } = {}
  payload = safeJsonParse(command.payload)

  const target = payload.path
    ? payload.path
    : payload.command
      ? payload.command.length > 48 ? payload.command.slice(0, 48) + '…' : payload.command
      : ''

  const isFinal = command.status === 'completed' || command.status === 'failed' || command.status === 'rejected'
  const label = command.status === 'completed' ? meta.labelDone
    : command.status === 'failed' ? meta.label
    : isFinal ? meta.labelDone : meta.label

  const isPending = command.status === 'pending'

  // Show "Abrir" chips for completed file/folder operations
  const showOpenChips =
    command.status === 'completed' &&
    payload.path &&
    (command.type === 'write_file' ||
      command.type === 'create_dir' ||
      command.type === 'read_dir' ||
      command.type === 'read_file' ||
      command.type === 'delete_file' ||
      command.type === 'open_path')

  return (
    <div
      onClick={() => onSelect(command.id)}
      className={`group rounded-xl px-3 py-2.5 transition cursor-pointer ${
        selected ? 'bg-zinc-100' : 'hover:bg-zinc-50'
      }`}
    >
      <div className="flex items-center gap-3">
        {/* Step number + status indicator */}
        <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 border" style={{
          background: command.status === 'completed' ? '#ecfdf5' : command.status === 'executing' ? '#18181b' : command.status === 'failed' ? '#fef2f2' : '#fafafa',
          borderColor: command.status === 'completed' ? '#86efac' : command.status === 'executing' ? '#3f3f46' : command.status === 'failed' ? '#fca5a5' : '#e4e4e7',
          color: command.status === 'completed' ? '#059669' : command.status === 'executing' ? '#fbbf24' : command.status === 'failed' ? '#dc2626' : '#a1a1aa',
        }}>
          {command.status === 'completed' ? '✓' : command.status === 'failed' ? '✕' : command.status === 'executing' ? (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          ) : (index + 1)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[15px] text-zinc-900">{label}</span>
            {target && (
              <span className="text-[13px] text-zinc-400 truncate">
                {target}
              </span>
            )}
          </div>
          {command.status === 'failed' && command.error && (
            <div className="text-xs text-rose-600 mt-1 line-clamp-2">
              {sanitizeError(command.error)}
            </div>
          )}
        </div>
      </div>

      {/* Smart action chips on completion */}
      {showOpenChips && (
        <div
          className="mt-2 ml-7 flex flex-wrap items-center gap-1.5"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Open file (for write_file, read_file) */}
          {(command.type === 'write_file' || command.type === 'read_file') && payload.path && (
            <button
              onClick={() => onOpenPath(payload.path!)}
              className="text-[11px] px-2.5 py-1 rounded-full border border-zinc-200 text-zinc-600 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition flex items-center gap-1"
              title={t('ce.chip_open_file')}
            >
              ↗ {t('ce.chip_open_file')}
            </button>
          )}
          {/* Open parent folder for files, or self for folders */}
          {command.type !== 'delete_file' && (
            <button
              onClick={() =>
                onOpenPath(
                  command.type === 'write_file' || command.type === 'read_file'
                    ? parentDir(payload.path)
                    : payload.path || '',
                )
              }
              className="text-[11px] px-2.5 py-1 rounded-full border border-zinc-200 text-zinc-600 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition flex items-center gap-1"
              title={t('ce.chip_open_folder')}
            >
              📁 {t('ce.chip_open_folder')}
            </button>
          )}
          {/* Preview HTML in right pane */}
          {command.type === 'write_file' && isHtmlPath(payload.path) && (
            <button
              onClick={() => onPreviewHtml(command.id)}
              className="text-[11px] px-2.5 py-1 rounded-full border border-zinc-200 text-zinc-600 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition flex items-center gap-1"
              title={t('ce.chip_preview')}
            >
              ◉ {t('ce.chip_preview')}
            </button>
          )}
        </div>
      )}

      {/* Live terminal output for execute_cmd — Apple-style log viewer */}
      {command.type === 'execute_cmd' && command.streamOutput && (
        <div className="mt-2 ml-7 rounded-xl bg-zinc-50 border border-zinc-200/80 text-[11px] font-mono p-3 max-h-[160px] overflow-y-auto whitespace-pre-wrap break-all scrollbar-thin scrollbar-thumb-zinc-300">
          <div className="flex items-center gap-1.5 text-zinc-400 mb-1.5 text-[10px]">
            {command.status === 'executing' ? (
              <>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                <span className="text-amber-600">{t('ce.terminal_live')}</span>
              </>
            ) : (
              <>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-zinc-300" />
                <span>{t('ce.terminal_output')}</span>
              </>
            )}
          </div>
          <div className="text-zinc-600 leading-relaxed">{command.streamOutput}</div>
        </div>
      )}

      {/* Pending confirmation buttons (delete / execute) */}
      {isPending && (
        <div
          className="mt-2 ml-7 flex items-center gap-2"
          onClick={(e) => e.stopPropagation()}
        >
          <span className="text-xs text-amber-700 flex items-center gap-1">
            <Shield className="w-3 h-3" />
            {t('ce.needs_approval')}
          </span>
          <button
            onClick={() => onConfirm(command.id)}
            className="text-xs px-3 py-1 rounded-full bg-zinc-900 text-white hover:bg-zinc-700 transition"
          >
            {t('ce.approve')}
          </button>
          <button
            onClick={() => onReject(command.id)}
            className="text-xs px-3 py-1 rounded-full border border-zinc-200 text-zinc-600 hover:bg-zinc-100 transition"
          >
            {t('ce.reject')}
          </button>
        </div>
      )}
    </div>
  )
}

// ----------------------------------------------------------------------------
// Friendly error sanitizer — trims stack traces & raw paths
// ----------------------------------------------------------------------------
function sanitizeError(err: string): string {
  if (!err) return 'Error'
  const firstLine = err.split('\n')[0]
  // Hide raw paths / stack-ish noise
  return firstLine.length > 120 ? firstLine.slice(0, 117) + '…' : firstLine
}

// ----------------------------------------------------------------------------
// Tiny markdown renderer — minimal subset (headings, bold/italic/links/inline)
// ----------------------------------------------------------------------------
function tinyMarkdown(src: string): string {
  const escape = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

  const lines = src.split('\n')
  const out: string[] = []
  let inCode = false
  let inList = false

  for (const ln of lines) {
    if (/^```/.test(ln)) {
      inCode = !inCode
      out.push(inCode ? '<pre class="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto"><code>' : '</code></pre>')
      continue
    }
    if (inCode) { out.push(escape(ln)); continue }

    if (/^#{1,6}\s/.test(ln)) {
      const lvl = ln.match(/^#+/)![0].length
      const text = ln.replace(/^#+\s/, '')
      const sizes = ['', 'text-2xl', 'text-xl', 'text-lg', 'text-base', 'text-sm', 'text-xs']
      out.push(`<h${lvl} class="font-semibold ${sizes[lvl] || 'text-base'} mt-3 mb-2 text-zinc-900">${escape(text)}</h${lvl}>`)
      continue
    }

    if (/^\s*[-*]\s/.test(ln)) {
      if (!inList) { out.push('<ul class="list-disc pl-5 space-y-1">'); inList = true }
      out.push(`<li>${inlineMd(escape(ln.replace(/^\s*[-*]\s/, '')))}</li>`)
      continue
    }
    if (inList) { out.push('</ul>'); inList = false }

    if (ln.trim() === '') { out.push('<br/>'); continue }

    out.push(`<p class="text-sm text-zinc-700 leading-relaxed">${inlineMd(escape(ln))}</p>`)
  }
  if (inList) out.push('</ul>')
  if (inCode) out.push('</code></pre>')

  return out.join('\n')
}
function inlineMd(s: string): string {
  return s
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code class="px-1 rounded bg-zinc-100 text-zinc-800 text-[12px]">$1</code>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-amber-600 underline" target="_blank" rel="noopener">$1</a>')
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Project Preview — combines HTML/CSS/JS from the same folder into one iframe
// ----------------------------------------------------------------------------
function buildProjectHtml(commands: BridgeCommand[]): string | null {
  // Collect completed write_file commands
  const writes = commands.filter(
    (c) => c.type === 'write_file' && c.status === 'completed',
  )
  if (writes.length === 0) return null

  // Parse payloads
  const files: { path: string; content: string }[] = []
  for (const w of writes) {
    try {
      const p = safeJsonParse(w.payload)
      if (p.path && p.content) files.push({ path: p.path, content: p.content })
    } catch {}
  }
  if (files.length === 0) return null

  // Find the HTML entry (prefer index.html, then any .html)
  const htmlFile =
    files.find((f) => /index\.html?$/i.test(f.path)) ||
    files.find((f) => /\.html?$/i.test(f.path))
  if (!htmlFile) return null

  // Figure out the project folder from the HTML file
  const htmlDir = htmlFile.path.replace(/\\/g, '/').split('/').slice(0, -1).join('/')

  // Find sibling CSS and JS files
  const cssFiles = files.filter((f) => {
    const p = f.path.replace(/\\/g, '/')
    return /\.css$/i.test(p) && (htmlDir === '' || p.startsWith(htmlDir + '/'))
  })
  const jsFiles = files.filter((f) => {
    const p = f.path.replace(/\\/g, '/')
    return /\.m?js$/i.test(p) && (htmlDir === '' || p.startsWith(htmlDir + '/'))
  })

  let html = htmlFile.content

  // Inject CSS files as <style> tags before </head> or at start
  if (cssFiles.length > 0) {
    const cssBlock = cssFiles
      .map((f) => `<style>/* ${f.path} */\n${f.content}</style>`)
      .join('\n')
    if (html.includes('</head>')) {
      html = html.replace('</head>', cssBlock + '\n</head>')
    } else {
      html = cssBlock + '\n' + html
    }
  }

  // Inject JS files as <script> tags before </body> or at end
  if (jsFiles.length > 0) {
    const jsBlock = jsFiles
      .map((f) => `<script>/* ${f.path} */\n${f.content}</script>`)
      .join('\n')
    if (html.includes('</body>')) {
      html = html.replace('</body>', jsBlock + '\n</body>')
    } else {
      html = html + '\n' + jsBlock
    }
  }

  return html
}

const PREVIEW_CACHE_KEY = 'octopus_preview_cache'

function cachePreview(html: string) {
  try { localStorage.setItem(PREVIEW_CACHE_KEY, html) } catch {}
}

function getCachedPreview(): string | null {
  try { return localStorage.getItem(PREVIEW_CACHE_KEY) } catch { return null }
}

function ProjectPreview({ commands, refreshKey, t, fullscreen }: { commands: BridgeCommand[]; refreshKey?: number; t: (key: string) => string; fullscreen?: boolean }) {
  const html = useMemo(() => buildProjectHtml(commands), [commands])
  const [showRaw, setShowRaw] = useState(false)
  const [isCached, setIsCached] = useState(false)

  // Cache new previews; fall back to cached version
  const displayHtml = useMemo(() => {
    if (html) {
      cachePreview(html)
      return html
    }
    const cached = getCachedPreview()
    if (cached) {
      setIsCached(true)
      return cached
    }
    return null
  }, [html])

  if (!displayHtml) {
    return (
      <PreviewShell title={t('ce.project_preview')}>
        <div className="flex flex-col items-center text-center py-12">
          <Eye className="w-7 h-7 text-zinc-300 mb-2" />
          <div className="text-sm text-zinc-500">{t('ce.project_no_html')}</div>
        </div>
      </PreviewShell>
    )
  }

  // In fullscreen mode, render iframe at 100% without shell
  if (fullscreen) {
    return (
      <iframe
        key={`project-fs-${refreshKey || 0}`}
        sandbox="allow-scripts allow-same-origin allow-modals allow-forms allow-popups"
        srcDoc={displayHtml}
        className="w-full h-full border-0"
        title="project-preview-fullscreen"
      />
    )
  }

  return (
    <PreviewShell title={t('ce.project_preview')}>
      <div className="mb-2 flex items-center justify-between">
        <div className="text-xs text-zinc-500 flex items-center gap-1.5">
          {t('ce.project_combined')}
          {isCached && !html && (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-600">{t('ce.cached')}</span>
          )}
        </div>
        <button
          onClick={() => setShowRaw((v) => !v)}
          className="text-xs text-zinc-500 hover:text-zinc-900 underline-offset-2 hover:underline"
        >
          {showRaw ? t('ce.view_render') : t('ce.view_code')}
        </button>
      </div>
      {showRaw ? (
        <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre-wrap break-all text-zinc-700 font-mono max-h-[60vh]">
          {displayHtml}
        </pre>
      ) : (
        <iframe
          key={`project-${refreshKey || 0}`}
          sandbox="allow-scripts allow-same-origin allow-modals allow-forms allow-popups"
          srcDoc={displayHtml}
          className="w-full rounded-lg border border-zinc-200 bg-white" style={{ height: "calc(100% - 2rem)", minHeight: "500px" }}
          title="project-preview"
        />
      )}
    </PreviewShell>
  )
}

// ----------------------------------------------------------------------------
// Smart preview — renders artifact based on type
// ----------------------------------------------------------------------------
function PreviewPanel({ command, commands, projectMode, refreshKey, t }: { command: BridgeCommand | null; commands?: BridgeCommand[]; projectMode?: boolean; refreshKey?: number; t: (key: string) => string }) {
  // Project preview mode: combine all files
  if (projectMode && commands && commands.length > 0) {
    return <ProjectPreview commands={commands} refreshKey={refreshKey} t={t} />
  }

  if (!command) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center px-6 select-none">
        <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center mb-3">
          <Sparkles className="w-5 h-5 text-zinc-400" />
        </div>
        <div className="text-[13px] text-zinc-400 max-w-[220px]">
          {t('ce.preview_empty')}
        </div>
      </div>
    )
  }

  let payload: { path?: string; command?: string; content?: string } = {}
  let result: { content?: string; entries?: { name: string; isDir: boolean }[]; stdout?: string; stderr?: string; written?: string; created?: string; deleted?: string; bytes?: number; path?: string } = {}
  try {
    // payload may be a string (from DB) or already an object (from SSE)
    payload = safeJsonParse(command.payload)
  } catch {}
  if (command.result) result = safeJsonParse(command.result)

  const isExecuting = command.status === 'executing' || command.status === 'approved'
  const isFailed = command.status === 'failed'
  const isPending = command.status === 'pending'
  const isRejected = command.status === 'rejected'

  // Loading / waiting states
  if (isPending) {
    return (
      <PreviewShell title={getActionMeta(command.type, t).label}>
        <div className="flex flex-col items-center text-center py-12">
          <Shield className="w-8 h-8 text-amber-500 mb-2" />
          <div className="text-sm text-zinc-700">{t('ce.pending_approval')}</div>
        </div>
      </PreviewShell>
    )
  }
  if (isExecuting) {
    return (
      <PreviewShell title={getActionMeta(command.type, t).label}>
        <div className="flex flex-col items-center text-center py-12">
          <Loader2 className="w-7 h-7 text-zinc-500 animate-spin mb-2" />
          <div className="text-sm text-zinc-500">{t('ce.executing')}</div>
        </div>
      </PreviewShell>
    )
  }
  if (isRejected) {
    return (
      <PreviewShell title={t('ce.preview_cancelled')}>
        <div className="text-sm text-zinc-500 py-8 text-center">
          {t('ce.preview_cancelled')}
        </div>
      </PreviewShell>
    )
  }
  if (isFailed) {
    return (
      <PreviewShell title={t('ce.preview_failed')}>
        <div className="flex flex-col items-center text-center py-8">
          <AlertTriangle className="w-8 h-8 text-rose-500 mb-2" />
          <div className="text-sm text-zinc-700 max-w-[280px]">
            {sanitizeError(command.error || '')}
          </div>
        </div>
      </PreviewShell>
    )
  }

  // Completed — dispatch by type / extension
  const path = (payload.path || result.path || result.written || result.created || '').toLowerCase()
  const ext = path.split('.').pop() || ''

  // write_file: render content based on extension
  if (command.type === 'write_file') {
    const content = payload.content ?? ''
    console.log('[Preview] write_file preview:', { path: payload.path, ext, contentLength: content.length, hasContent: !!content, contentPreview: content.substring(0, 100) })
    return <WrittenPreview path={payload.path || ''} ext={ext} content={content} refreshKey={refreshKey} t={t} />
  }

  if (command.type === 'read_file' && result.content) {
    return <WrittenPreview path={payload.path || ''} ext={ext} content={result.content} refreshKey={refreshKey} t={t} />
  }

  if (command.type === 'create_dir') {
    return (
      <PreviewShell title={t('ce.preview_folder_created')}>
        <div className="flex flex-col items-center text-center py-10">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center mb-3">
            <Folder className="w-7 h-7 text-amber-600" />
          </div>
          <div className="text-sm font-medium text-zinc-900">{payload.path}</div>
        </div>
      </PreviewShell>
    )
  }

  if (command.type === 'read_dir' && result.entries) {
    return (
      <PreviewShell title={payload.path || ''}>
        <div className="divide-y divide-zinc-100">
          {result.entries.length === 0 ? (
            <div className="text-sm text-zinc-400 py-6 text-center">—</div>
          ) : (
            result.entries.map((e) => (
              <div key={e.name} className="flex items-center gap-2 py-2 text-sm">
                <span>{e.isDir ? '📁' : '📄'}</span>
                <span className="text-zinc-700">{e.name}</span>
              </div>
            ))
          )}
        </div>
      </PreviewShell>
    )
  }

  if (command.type === 'delete_file') {
    return (
      <PreviewShell title={t('ce.preview_deleted')}>
        <div className="flex flex-col items-center text-center py-10">
          <Trash2 className="w-7 h-7 text-zinc-400 mb-2" />
          <div className="text-sm text-zinc-700">{payload.path}</div>
        </div>
      </PreviewShell>
    )
  }

  if (command.type === 'execute_cmd') {
    return (
      <PreviewShell title={t('ce.preview_cmd_result')}>
        {result.stdout && (
          <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre-wrap break-all text-zinc-700 font-mono max-h-[400px]">
            {result.stdout}
          </pre>
        )}
        {result.stderr && (
          <pre className="text-xs bg-rose-50 rounded-lg p-3 mt-2 overflow-auto whitespace-pre-wrap break-all text-rose-700 font-mono max-h-[200px]">
            {result.stderr}
          </pre>
        )}
        {!result.stdout && !result.stderr && (
          <div className="text-sm text-zinc-400 text-center py-6">—</div>
        )}
      </PreviewShell>
    )
  }

  return (
    <PreviewShell title={t('ce.preview_ready')}>
      <div className="text-sm text-zinc-500 py-6 text-center">✓</div>
    </PreviewShell>
  )
}

function PreviewShell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col h-full">
      <div className="px-1 pb-2 text-[11px] uppercase tracking-[0.18em] text-zinc-400">{title}</div>
      <div className="flex-1 overflow-auto">{children}</div>
    </div>
  )
}



// Render the contents of a written/read file based on extension
function WrittenPreview({ path: filePath, ext, content, refreshKey, t }: { path: string; ext: string; content: string; refreshKey?: number; t: (key: string) => string }) {
  const [showRaw, setShowRaw] = useState(false)

  // Cache HTML previews for offline access
  useEffect(() => {
    if ((ext === 'html' || ext === 'htm') && content) {
      cachePreview(content)
    }
  }, [ext, content])

  if (ext === 'html' || ext === 'htm') {
    console.log('[WrittenPreview] Rendering HTML iframe, content length:', content.length, 'showRaw:', showRaw)
    return (
      <PreviewShell title={t('ce.preview_title')}>
        <div className="mb-2 flex items-center justify-between">
          <div className="text-xs text-zinc-500 truncate">{filePath}</div>
          <button
            onClick={() => setShowRaw((v) => !v)}
            className="text-xs text-zinc-500 hover:text-zinc-900 underline-offset-2 hover:underline"
          >
            {showRaw ? t('ce.view_render') : t('ce.view_code')}
          </button>
        </div>
        {showRaw ? (
          <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre-wrap break-all text-zinc-700 font-mono max-h-[60vh]">
            {content}
          </pre>
        ) : (
          <iframe
            key={`preview-${refreshKey || 0}`}
            sandbox="allow-scripts allow-same-origin allow-modals allow-forms allow-popups"
            srcDoc={content}
            className="w-full rounded-lg border border-zinc-200 bg-white" style={{ height: "calc(100% - 2rem)", minHeight: "500px" }}
            title="preview"
            onLoad={() => console.log('[WrittenPreview] iframe loaded!')}
          />
        )}
      </PreviewShell>
    )
  }

  if (ext === 'md' || ext === 'markdown') {
    return (
      <PreviewShell title={t('ce.preview_title')}>
        <div className="mb-2 flex items-center justify-between">
          <div className="text-xs text-zinc-500 truncate">{filePath}</div>
          <button
            onClick={() => setShowRaw((v) => !v)}
            className="text-xs text-zinc-500 hover:text-zinc-900 underline-offset-2 hover:underline"
          >
            {showRaw ? t('ce.view_render') : t('ce.view_code')}
          </button>
        </div>
        {showRaw ? (
          <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre-wrap break-all text-zinc-700 font-mono max-h-[60vh]">
            {content}
          </pre>
        ) : (
          <div
            className="prose-sm max-w-none text-zinc-800"
            dangerouslySetInnerHTML={{ __html: tinyMarkdown(content) }}
          />
        )}
      </PreviewShell>
    )
  }

  if (ext === 'json') {
    let pretty = content
    try { pretty = JSON.stringify(JSON.parse(content), null, 2) } catch {}
    return (
      <PreviewShell title={t('ce.preview_title')}>
        <div className="mb-2 text-xs text-zinc-500 truncate">{filePath}</div>
        <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre break-all text-zinc-700 font-mono max-h-[60vh]">
          {pretty}
        </pre>
      </PreviewShell>
    )
  }

  // Generic text preview
  return (
    <PreviewShell title={t('ce.preview_title')}>
      <div className="mb-2 flex items-center justify-between">
        <div className="text-xs text-zinc-500 truncate">{filePath}</div>
      </div>
      {content.length === 0 ? (
        <div className="text-sm text-zinc-400 text-center py-8">—</div>
      ) : (
        <pre className="text-xs bg-zinc-50 rounded-lg p-3 overflow-auto whitespace-pre-wrap break-all text-zinc-700 font-mono max-h-[60vh]">
          {content.length > 5000 ? content.slice(0, 5000) + '\n…' : content}
        </pre>
      )}
    </PreviewShell>
  )
}

// ============================================================================
// EXECUTION BANNER — phase indicator + progress bar + current step
// ============================================================================
function ExecutionBanner({
  commands,
  isThinking,
  streamingText,
  t,
}: {
  commands: BridgeCommand[]
  isThinking: boolean
  streamingText: string
  t: (key: string) => string
}) {
  const totalCommands = commands.length
  const completedCount = commands.filter((c) =>
    ['completed', 'failed', 'rejected'].includes(c.status),
  ).length
  const executingCmd = commands.find((c) => c.status === 'executing')
  const pendingCmds = commands.filter((c) => c.status === 'approved' || c.status === 'pending')
  const hasFailure = commands.some((c) => c.status === 'failed')
  const allDone = totalCommands > 0 && completedCount === totalCommands

  // Derive phase — ALWAYS show when commands exist or thinking
  type Phase = 'idle' | 'thinking' | 'executing' | 'completed' | 'failed'
  let phase: Phase = 'idle'
  if (isThinking && totalCommands === 0) phase = 'thinking'
  else if (executingCmd || pendingCmds.length > 0) phase = 'executing'
  else if (isThinking && totalCommands > 0) phase = 'executing'
  else if (hasFailure && allDone) phase = 'failed'
  else if (allDone && totalCommands > 0) phase = 'completed'
  else if (totalCommands > 0) phase = 'completed'

  // Debug logging — helps trace banner visibility issues
  useEffect(() => {
    console.log('[ExecBanner]', { phase, isThinking, totalCommands, completedCount, pendingCount: pendingCmds.length, hasExecuting: !!executingCmd })
  }, [phase, isThinking, totalCommands, completedCount, pendingCmds.length, executingCmd])

  // Auto-dismiss completed/failed banner after 15 seconds
  const [dismissed, setDismissed] = useState(false)
  const [stuckWarning, setStuckWarning] = useState(false)
  const prevPhaseRef = useRef(phase)
  useEffect(() => {
    if (phase !== prevPhaseRef.current) {
      setDismissed(false)
      setStuckWarning(false)
      prevPhaseRef.current = phase
    }
    if (phase === 'completed' || phase === 'failed') {
      const timer = setTimeout(() => setDismissed(true), 15000)
      return () => clearTimeout(timer)
    }
    // Stuck detection: if executing for >45s, show warning
    if (phase === 'executing') {
      const stuckTimer = setTimeout(() => setStuckWarning(true), 45000)
      return () => clearTimeout(stuckTimer)
    }
  }, [phase])

  if (phase === 'idle' || dismissed) return null

  const progress = totalCommands > 0 ? Math.round((completedCount / totalCommands) * 100) : 0

  // Current step description
  let currentStep = ''
  if (executingCmd) {
    const meta = getActionMeta(executingCmd.type, t)
    let payload: { path?: string; command?: string } = {}
    payload = safeJsonParse(executingCmd.payload)
    const target = payload.path || (payload.command ? payload.command.slice(0, 40) : '')
    currentStep = target ? `${meta.label} · ${target}` : meta.label
  }

  const isDark = phase === 'thinking' || phase === 'executing'

  return (
    <div
      className="rounded-2xl border overflow-hidden mb-3 shadow-lg animate-in fade-in slide-in-from-top-2 duration-300"
      style={{
        background: isDark ? '#18181b' : phase === 'completed' ? '#f0fdf4' : '#fef2f2',
        borderColor: isDark ? '#27272a' : phase === 'completed' ? '#bbf7d0' : '#fecaca',
      }}
    >
      {/* Top bar: Progress X/Y ████████ XX% */}
      <div className="px-4 pt-3 pb-2">
        <div className="flex items-center gap-3">
          <span className={`text-xs font-semibold uppercase tracking-wider ${isDark ? 'text-zinc-400' : 'text-zinc-500'}`}>
            {t('ce.phase_progress')}
          </span>
          <span className={`text-xs font-bold tabular-nums ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            {completedCount}/{totalCommands}
          </span>
          {/* Progress bar */}
          <div className={`flex-1 h-2.5 rounded-full overflow-hidden ${isDark ? 'bg-zinc-700' : phase === 'completed' ? 'bg-emerald-200' : 'bg-rose-200'}`}>
            {phase === 'thinking' && totalCommands === 0 ? (
              <div className="h-full w-full relative">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-400/60 to-transparent animate-[shimmer_1.5s_infinite]" />
              </div>
            ) : (
              <div
                className={`h-full rounded-full transition-all duration-500 ease-out ${
                  phase === 'completed' ? 'bg-emerald-500' : phase === 'failed' ? 'bg-rose-500' : 'bg-amber-400'
                }`}
                style={{ width: `${Math.max(progress, totalCommands > 0 ? 5 : 0)}%` }}
              />
            )}
          </div>
          <span className={`text-xs font-bold tabular-nums min-w-[36px] text-right ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>
            {progress}%
          </span>
        </div>
      </div>

      {/* Phase status label */}
      <div className="px-4 pb-2 flex items-center gap-2">
        {phase === 'thinking' && (
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs font-medium text-amber-400">{t('ce.phase_analyzing')}</span>
            <span className="inline-flex gap-[3px]">
              <span className="w-1 h-1 rounded-full bg-zinc-500 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1 h-1 rounded-full bg-zinc-500 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1 h-1 rounded-full bg-zinc-500 animate-bounce" style={{ animationDelay: '300ms' }} />
            </span>
          </div>
        )}
        {phase === 'executing' && (
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs font-medium text-amber-400">⚡ {t('ce.phase_executing')}</span>
            {currentStep && <span className="text-[11px] text-zinc-500 truncate">— {currentStep}</span>}
          </div>
        )}
        {phase === 'completed' && (
          <span className="text-xs font-medium text-emerald-600">✅ {t('ce.phase_completed')}</span>
        )}
        {phase === 'failed' && (
          <span className="text-xs font-medium text-rose-600">❌ {t('ce.phase_failed')}</span>
        )}
      </div>

      {/* Streaming thought preview */}
      {phase === 'thinking' && streamingText && (
        <div className="px-4 pb-2 text-[11px] text-zinc-500 leading-relaxed line-clamp-2 italic">
          {streamingText.slice(-200)}
        </div>
      )}

      {/* Stuck warning */}
      {stuckWarning && phase === 'executing' && (
        <div className="px-4 pb-2">
          <div className="flex items-center gap-2 text-[11px] bg-amber-900/40 rounded-lg px-3 py-2 border border-amber-700/50">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
            <span className="text-amber-300">Bridge may be taking longer than expected. Check your local Bridge connection.</span>
          </div>
        </div>
      )}

      {/* Numbered steps list */}
      {totalCommands > 0 && (
        <div className="px-4 pb-3 space-y-1">
          {commands.slice(-5).map((cmd) => {
            const meta = getActionMeta(cmd.type, t)
            let p: { path?: string; command?: string } = {}
            p = safeJsonParse(cmd.payload)
            const label = p.path || (p.command ? p.command.slice(0, 40) : meta.label)
            const isDone = cmd.status === 'completed'
            const isFail = cmd.status === 'failed'
            const isExec = cmd.status === 'executing'
            return (
              <div key={cmd.id} className="flex items-center gap-2 text-[11px]">
                <span className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold ${
                  isDone ? 'bg-emerald-500/20 text-emerald-400' :
                  isFail ? 'bg-rose-500/20 text-rose-400' :
                  isExec ? 'bg-amber-500/20 text-amber-400' :
                  'bg-zinc-600 text-zinc-400'
                }`}>
                  {isDone ? '✓' : isFail ? '✗' : isExec ? '⚡' : (commands.indexOf(cmd) + 1)}
                </span>
                <span className={`truncate ${isDone ? 'text-zinc-500 line-through' : isFail ? 'text-rose-400' : isExec ? 'text-amber-300' : isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                  {meta.emoji} {label}
                </span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================
export default function CodeEnginePage() {
  const { t } = useI18n()
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const feedRef = useRef<HTMLDivElement>(null)

  const [bridgeStatus, setBridgeStatus] = useState<BridgeStatus | null>(null)
  const [statusLoading, setStatusLoading] = useState(true)

  const [sessions, setSessions] = useState<CodeSession[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)
  const [messages, setMessages] = useState<CodeMessage[]>([])
  const [commands, setCommands] = useState<BridgeCommand[]>([])

  const [selectedModel, setSelectedModelRaw] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('octopus_ce_model') || DEFAULT_MODEL
    }
    return DEFAULT_MODEL
  })
  // Wrap setter to persist to localStorage
  const setSelectedModel = useCallback((model: string) => {
    setSelectedModelRaw(model)
    try { localStorage.setItem('octopus_ce_model', model) } catch {}
  }, [])
  const [showModelSelect, setShowModelSelect] = useState(false)
  const [showSessions, setShowSessions] = useState(false)
  const [previewCmdId, setPreviewCmdId] = useState<string | null>(null)
  const [projectPreview, setProjectPreview] = useState(false)

  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [lastUserMessage, setLastUserMessage] = useState<string>('')
  const [showDetails, setShowDetails] = useState(false)

  // Workspace intelligence state
  const [rightTab, setRightTab] = useState<'preview' | 'workspace'>('preview')
  const [workspace, setWorkspace] = useState<WorkspaceData | null>(null)
  const [recentChanges, setRecentChanges] = useState<FileChangeItem[]>([])

  // Preview panel state
  const [previewExpanded, setPreviewExpanded] = useState(false)
  const [previewRefreshKey, setPreviewRefreshKey] = useState(0)
  const prevCompletedRef = useRef(0)

  const sseRef = useRef<EventSource | null>(null)

  // ESC key to close fullscreen preview
  useEffect(() => {
    if (!previewExpanded) return
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setPreviewExpanded(false) }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [previewExpanded])

  // ---- Status / sessions ----
  const fetchStatus = useCallback(async () => {
    try {
      const r = await fetch('/api/arms/ollama/status')
      if (r.ok) {
        const data = await r.json()
        const st = data.status || data
        const lastSeen = st.lastSeenAt ? new Date(st.lastSeenAt).getTime() : 0
        const online = !!st.bridgePresent && Date.now() - lastSeen < 3 * 60 * 1000
        setBridgeStatus({ online, lastSeen: st.lastSeenAt })
      } else {
        setBridgeStatus({ online: false })
      }
    } catch {
      setBridgeStatus({ online: false })
    } finally {
      setStatusLoading(false)
    }
  }, [])

  const fetchSessions = useCallback(async () => {
    try {
      const r = await fetch('/api/arms/claude-code/chat?action=sessions')
      if (r.ok) {
        const data = await r.json()
        setSessions(data.sessions || [])
      }
    } catch {}
  }, [])

  const fetchSession = useCallback(async (sessionId: string, restoreModel = true) => {
    try {
      const r = await fetch(`/api/arms/claude-code/chat?action=messages&sessionId=${sessionId}`)
      if (r.ok) {
        const data = await r.json()
        setMessages(data.messages || [])
        // Merge commands from DB with existing state — prefer DB status (more recent)
        // but don't clobber optimistic SSE updates that may be more up-to-date
        const dbCommands: BridgeCommand[] = data.commands || []
        setCommands((prev) => {
          if (prev.length === 0) return dbCommands
          const map = new Map(prev.map((c) => [c.id, c]))
          for (const dc of dbCommands) {
            const existing = map.get(dc.id)
            if (!existing) {
              map.set(dc.id, dc)
            } else {
              // DB is source of truth — update status, result, error
              map.set(dc.id, { ...existing, status: dc.status, result: dc.result, error: dc.error })
            }
          }
          return Array.from(map.values())
        })
        // Only restore the session's model when switching sessions, not after sending a message
        if (restoreModel && data.session?.model) setSelectedModel(data.session.model)
      }
    } catch (err) {
      console.error('[fetchSession] Error:', err)
    }
  }, [setSelectedModel])

  // Fallback: fetch all commands from REST (used on session load & after confirm/reject)
  const fetchCommands = useCallback(async () => {
    if (!activeSessionId) return
    try {
      const r = await fetch(`/api/arms/claude-code/chat?action=commands&sessionId=${activeSessionId}`)
      if (r.ok) {
        const data = await r.json()
        setCommands(data.commands || [])
      }
    } catch {}
  }, [activeSessionId])

  // Workspace intelligence fetchers
  const fetchWorkspace = useCallback(async () => {
    try {
      const r = await fetch('/api/arms/claude-code/workspace?action=index')
      if (r.ok) {
        const data = await r.json()
        setWorkspace(data)
      }
    } catch {}
  }, [])

  const fetchRecentChanges = useCallback(async () => {
    try {
      const since = new Date(Date.now() - 60 * 60 * 1000).toISOString()
      const r = await fetch(`/api/arms/claude-code/workspace?action=changes&since=${since}`)
      if (r.ok) {
        const data = await r.json()
        setRecentChanges(data.changes || [])
      }
    } catch {}
  }, [])

  useEffect(() => {
    fetchStatus()
    fetchSessions()
    fetchWorkspace()
    fetchRecentChanges()
    const interval = setInterval(fetchStatus, 30000)
    const wsInterval = setInterval(() => { fetchWorkspace(); fetchRecentChanges() }, 30000)
    return () => { clearInterval(interval); clearInterval(wsInterval) }
  }, [fetchStatus, fetchSessions, fetchWorkspace, fetchRecentChanges])

  useEffect(() => {
    if (activeSessionId) {
      fetchSession(activeSessionId)
    } else {
      setMessages([])
      setCommands([])
      setPreviewCmdId(null)
      setProjectPreview(false)
    }
  }, [activeSessionId, fetchSession])

  // ── SSE Real-Time Stream ─────────────────────────────────────────────
  // Subscribes to /api/arms/claude-code/stream for real-time command updates.
  useEffect(() => {
    // Close previous SSE connection
    if (sseRef.current) {
      sseRef.current.close()
      sseRef.current = null
    }
    if (!activeSessionId) return

    const es = new EventSource(`/api/arms/claude-code/stream?sessionId=${activeSessionId}`)
    sseRef.current = es

    es.onopen = () => {
      console.log('[SSE] Connected to stream for session', activeSessionId)
    }

    es.addEventListener('command_new', (e) => {
      try {
        const cmd = JSON.parse(e.data) as {
          id: string; type: string; payload: Record<string, unknown>
          status: string; requiresConfirmation: boolean; createdAt: string
        }
        console.log('[SSE] command_new:', cmd.id, cmd.type, cmd.status)
        setCommands((prev) => {
          if (prev.some((c) => c.id === cmd.id)) return prev
          return [...prev, {
            id: cmd.id,
            sessionId: activeSessionId,
            messageId: null,
            type: cmd.type,
            payload: JSON.stringify(cmd.payload),
            status: cmd.status as BridgeCommand['status'],
            result: null,
            error: null,
            streamOutput: null,
            requiresConfirmation: cmd.requiresConfirmation,
            createdAt: cmd.createdAt,
          }]
        })
      } catch (err) {
        console.error('[SSE] Failed to parse command_new:', err, e.data)
      }
    })

    es.addEventListener('command_update', (e) => {
      try {
        const upd = JSON.parse(e.data) as { id: string; status: string; result?: unknown; error?: string | null }
        console.log('[SSE] command_update:', upd.id, upd.status)
        setCommands((prev) =>
          prev.map((c) =>
            c.id === upd.id
              ? {
                  ...c,
                  status: upd.status as BridgeCommand['status'],
                  result: upd.result !== undefined ? JSON.stringify(upd.result) : c.result,
                  error: upd.error ?? c.error,
                }
              : c,
          ),
        )
      } catch (err) {
        console.error('[SSE] Failed to parse command_update:', err, e.data)
      }
    })

    es.addEventListener('stream_output', (e) => {
      try {
        const so = JSON.parse(e.data) as { id: string; delta: string; total: number }
        setCommands((prev) =>
          prev.map((c) =>
            c.id === so.id
              ? { ...c, streamOutput: (c.streamOutput || '') + so.delta }
              : c,
          ),
        )
      } catch (err) {
        console.error('[SSE] Failed to parse stream_output:', err)
      }
    })

    es.onerror = (err) => {
      console.warn('[SSE] Connection error, will auto-reconnect', err)
    }

    return () => {
      es.close()
      sseRef.current = null
    }
  }, [activeSessionId])

  // ── Fallback Polling for Command Status ───────────────────────────────
  // If SSE misses events (connection drops, etc.), poll every 3s while
  // there are non-terminal commands. Merges updates without clobbering.
  useEffect(() => {
    if (!activeSessionId) return
    const hasActiveCommands = commands.some((c) =>
      c.status === 'approved' || c.status === 'executing' || c.status === 'pending',
    )
    if (!hasActiveCommands && !sending) return

    const interval = setInterval(async () => {
      try {
        const r = await fetch(`/api/arms/claude-code/chat?action=commands&sessionId=${activeSessionId}`)
        if (!r.ok) return
        const data = await r.json()
        const fresh: BridgeCommand[] = data.commands || []
        if (fresh.length === 0) return
        setCommands((prev) => {
          const map = new Map(prev.map((c) => [c.id, c]))
          let changed = false
          for (const fc of fresh) {
            const existing = map.get(fc.id)
            if (!existing) {
              map.set(fc.id, fc)
              changed = true
            } else if (existing.status !== fc.status || existing.result !== fc.result) {
              map.set(fc.id, { ...existing, status: fc.status, result: fc.result, error: fc.error })
              changed = true
            }
          }
          return changed ? Array.from(map.values()) : prev
        })
      } catch {}
    }, 3000)

    return () => clearInterval(interval)
  }, [activeSessionId, commands, sending])

  useEffect(() => {
    feedRef.current?.scrollTo({ top: feedRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, commands])

  // ── Stuck Command Recovery ────────────────────────────────────────────
  // If commands stay in 'executing' for >90s with no progress, force them
  // to 'completed' client-side so the UI doesn't stay stuck forever.
  const stuckTimerRef = useRef<NodeJS.Timeout | null>(null)
  useEffect(() => {
    const executingCmds = commands.filter((c) => c.status === 'executing')
    if (executingCmds.length === 0 || sending) {
      if (stuckTimerRef.current) { clearTimeout(stuckTimerRef.current); stuckTimerRef.current = null }
      return
    }
    // Start a 90s timer — if executing commands don't resolve, force-complete them
    if (!stuckTimerRef.current) {
      stuckTimerRef.current = setTimeout(() => {
        console.warn('[StuckRecovery] Force-completing stuck commands after 90s')
        setCommands((prev) =>
          prev.map((c) =>
            c.status === 'executing'
              ? { ...c, status: 'completed' as const, result: '(completed — Bridge response delayed)' }
              : c,
          ),
        )
        stuckTimerRef.current = null
      }, 90000)
    }
    return () => {
      if (stuckTimerRef.current) { clearTimeout(stuckTimerRef.current); stuckTimerRef.current = null }
    }
  }, [commands, sending])

  // Auto-select latest command for preview + auto-switch to project mode + auto-refresh
  useEffect(() => {
    if (commands.length === 0) {
      setPreviewCmdId(null)
      setProjectPreview(false)
      prevCompletedRef.current = 0
      return
    }
    const completedCount = commands.filter((c) => c.status === 'completed').length

    // Detect newly completed commands → force iframe re-render
    if (completedCount > prevCompletedRef.current) {
      setPreviewRefreshKey((k) => k + 1)
      // Auto-select latest completed write_file (prefer HTML)
      const completedWrites = commands.filter((c) => c.type === 'write_file' && c.status === 'completed')
      if (completedWrites.length > 0) {
        const htmlWrite = [...completedWrites].reverse().find((c) => {
          try { return isHtmlPath(safeJsonParse(c.payload).path) } catch { return false }
        })
        const pick = htmlWrite || completedWrites[completedWrites.length - 1]
        setPreviewCmdId(pick.id)
        // Switch to right tab preview automatically
        setRightTab('preview')
      }
    }
    prevCompletedRef.current = completedCount

    // Prefer the latest non-rejected command if nothing selected
    const current = commands.find((c) => c.id === previewCmdId)
    if (!current) {
      const latest = [...commands].reverse().find((c) => c.status !== 'rejected') || commands[commands.length - 1]
      setPreviewCmdId(latest.id)
    }
    // Auto-switch to project preview if there's a completed HTML file + other files
    const completedWrites = commands.filter((c) => c.type === 'write_file' && c.status === 'completed')
    if (completedWrites.length >= 2) {
      const hasHtml = completedWrites.some((c) => {
        try { const p = safeJsonParse(c.payload); return isHtmlPath(p.path) } catch { return false }
      })
      if (hasHtml && !projectPreview) setProjectPreview(true)
    }
  }, [commands, previewCmdId, projectPreview])

  // Latest user question (shown in title area)
  const currentTitle = useMemo(() => {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user')
    if (lastUser) return lastUser.content
    if (lastUserMessage) return lastUserMessage
    return t('ce.title_empty')
  }, [messages, lastUserMessage, t])

  const isThinking = sending || messages.some((m) => m.role === 'assistant' && m.status === 'streaming')
  const isExecutingAny = commands.some((c) => c.status === 'executing' || c.status === 'approved')

  // Debug: trace thinking/sending state changes
  useEffect(() => {
    if (isThinking || commands.length > 0) {
      console.log('[CodeEngine] isThinking=', isThinking, 'sending=', sending, 'commands=', commands.length, 'cmdStatuses=', commands.map(c => c.status))
    }
  }, [isThinking, sending, commands])

  // Compute live preview URL from Bridge local server
  const livePreviewUrl = useMemo(() => {
    const completedWrites = commands.filter((c) => c.type === 'write_file' && c.status === 'completed')
    if (completedWrites.length === 0) return null
    // Find HTML file to preview
    const htmlWrite = completedWrites.find((c) => {
      try { return isHtmlPath(safeJsonParse(c.payload).path) } catch { return false }
    })
    if (!htmlWrite) return null
    try {
      const p = safeJsonParse(htmlWrite.payload).path as string
      return `http://localhost:9753/${p.replace(/\\/g, '/')}`
    } catch { return null }
  }, [commands])

  const previewCmd = useMemo(
    () => commands.find((c) => c.id === previewCmdId) || null,
    [commands, previewCmdId],
  )

  // ---- Send ----
  const sendMessage = async () => {
    const trimmed = input.trim()
    if (!trimmed || sending) return
    if (!bridgeStatus?.online) return

    setSending(true)
    setInput('')
    setLastUserMessage(trimmed)
    // Reset textarea height
    if (inputRef.current) {
      inputRef.current.style.height = 'auto'
      inputRef.current.style.overflowY = 'hidden'
    }

    // Optimistic
    const tempUserMsg: CodeMessage = {
      id: `temp-user-${Date.now()}`,
      role: 'user',
      content: trimmed,
      status: 'completed',
      createdAt: new Date().toISOString(),
    }
    const tempAssistantMsg: CodeMessage = {
      id: `temp-asst-${Date.now()}`,
      role: 'assistant',
      content: '',
      status: 'streaming',
      createdAt: new Date().toISOString(),
    }
    setMessages((prev) => [...prev, tempUserMsg, tempAssistantMsg])

    try {
      const res = await fetch('/api/arms/claude-code/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: activeSessionId, model: selectedModel, message: trimmed }),
      })
      if (!res.ok || !res.body) {
        const err = await res.text().catch(() => 'unknown error')
        setMessages((prev) =>
          prev.map((m) =>
            m.id === tempAssistantMsg.id
              ? { ...m, status: 'failed' as const, error: err.slice(0, 200) }
              : m,
          ),
        )
        return
      }
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let realSessionId: string | null = activeSessionId
      let realMessageId: string | null = null
      let accumulated = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const events = buffer.split('\n\n')
        buffer = events.pop() || ''
        for (const ev of events) {
          const lines = ev.split('\n')
          let eventName = 'message'
          let dataStr = ''
          for (const ln of lines) {
            if (ln.startsWith('event:')) eventName = ln.slice(6).trim()
            else if (ln.startsWith('data:')) dataStr += ln.slice(5).trim()
          }
          if (!dataStr) continue
          let data: { sessionId?: string; messageId?: string; content?: string; commands?: BridgeCommand[]; error?: string; detail?: string } = {}
          try { data = JSON.parse(dataStr) } catch { continue }

          if (eventName === 'session') {
            realSessionId = data.sessionId || realSessionId
            realMessageId = data.messageId || null
            if (!activeSessionId && realSessionId) setActiveSessionId(realSessionId)
            if (realMessageId) {
              setMessages((prev) =>
                prev.map((m) => (m.id === tempAssistantMsg.id ? { ...m, id: realMessageId! } : m)),
              )
            }
          } else if (eventName === 'delta' && data.content) {
            accumulated += data.content
            const targetId = realMessageId || tempAssistantMsg.id
            setMessages((prev) =>
              prev.map((m) => (m.id === targetId ? { ...m, content: accumulated } : m)),
            )
          } else if (eventName === 'commands' && data.commands) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const incoming = data.commands as any[]
            setCommands((prev) => {
              const ids = new Set(prev.map((c) => c.id))
              const fresh = incoming
                .filter((c) => !ids.has(c.id))
                .map((c) => ({
                  ...c,
                  // Normalize payload to string — SSE sends it as object, but BridgeCommand expects string
                  payload: typeof c.payload === 'string' ? c.payload : JSON.stringify(c.payload || {}),
                  status: c.status || (c.needsConfirm ? 'pending' : 'approved'),
                }))
              console.log('[Chat] commands event:', fresh.length, 'new commands', fresh.map((c: { id: string; status: string }) => `${c.id}:${c.status}`))
              return [...prev, ...fresh]
            })
          } else if (eventName === 'done') {
            const targetId = realMessageId || tempAssistantMsg.id
            setMessages((prev) =>
              prev.map((m) => (m.id === targetId ? { ...m, status: 'completed' as const } : m)),
            )
          } else if (eventName === 'error') {
            const targetId = realMessageId || tempAssistantMsg.id
            setMessages((prev) =>
              prev.map((m) =>
                m.id === targetId
                  ? { ...m, status: 'failed' as const, error: data.detail || data.error || 'Error' }
                  : m,
              ),
            )
          }
        }
      }
      if (realSessionId) {
        await fetchSession(realSessionId, false)
        // Burst-poll command statuses for 20s to catch rapid Bridge execution
        // Bridge polls every 2s, so we poll every 1.5s to stay ahead
        let burstCount = 0
        const burstMax = 13 // ~20 seconds
        const burstInterval = setInterval(async () => {
          burstCount++
          try {
            const r = await fetch(`/api/arms/claude-code/chat?action=commands&sessionId=${realSessionId}`)
            if (!r.ok) return
            const d = await r.json()
            const fresh: BridgeCommand[] = d.commands || []
            if (fresh.length === 0) return
            setCommands((prev) => {
              const map = new Map(prev.map((c) => [c.id, c]))
              let changed = false
              for (const fc of fresh) {
                const existing = map.get(fc.id)
                if (!existing) {
                  map.set(fc.id, fc)
                  changed = true
                } else if (existing.status !== fc.status || existing.result !== fc.result) {
                  map.set(fc.id, { ...existing, status: fc.status, result: fc.result, error: fc.error })
                  changed = true
                }
              }
              return changed ? Array.from(map.values()) : prev
            })
            // Stop early if all commands are terminal
            const allTerminal = fresh.every((c) =>
              c.status === 'completed' || c.status === 'failed' || c.status === 'rejected',
            )
            if (allTerminal || burstCount >= burstMax) {
              console.log(`[Burst] Stopping after ${burstCount} polls — allTerminal=${allTerminal}`)
              clearInterval(burstInterval)
            }
          } catch {
            // Silently continue
          }
        }, 1500)
      }
      fetchSessions()
    } catch (e) {
      const msg = e instanceof Error ? e.message : t('ce.error_network')
      setMessages((prev) =>
        prev.map((m) =>
          m.id === tempAssistantMsg.id ? { ...m, status: 'failed' as const, error: msg } : m,
        ),
      )
    } finally {
      setSending(false)
    }
  }

  const handleConfirm = async (commandId: string) => {
    try {
      await fetch('/api/arms/claude-code/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ commandId, decision: 'approve' }),
      })
      fetchCommands()
    } catch {}
  }
  const handleReject = async (commandId: string) => {
    try {
      await fetch('/api/arms/claude-code/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ commandId, decision: 'reject' }),
      })
      fetchCommands()
    } catch {}
  }

  // Open a file or folder in the user's native explorer (via Bridge)
  const handleOpenPath = async (targetPath: string) => {
    if (!activeSessionId) return
    try {
      const r = await fetch('/api/arms/claude-code/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: activeSessionId, path: targetPath }),
      })
      if (r.ok) {
        // Refresh after a short delay so the new "open_path" command shows up
        setTimeout(() => fetchCommands(), 600)
      } else {
        const data = await r.json().catch(() => ({}))
        console.error('[OPEN_PATH] Error:', data.error || r.statusText)
      }
    } catch (e) {
      console.error('[OPEN_PATH] Fetch error:', e)
    }
  }

  // Select an HTML write_file command for preview in right pane
  const handlePreviewHtml = (cmdId: string) => {
    setPreviewCmdId(cmdId)
    setProjectPreview(false) // single-file preview
  }

  const newSession = () => {
    setActiveSessionId(null)
    setMessages([])
    setCommands([])
    setLastUserMessage('')
    setPreviewCmdId(null)
    setProjectPreview(false)
    setInput('')
    inputRef.current?.focus()
  }

  const deleteSession = async (sid: string) => {
    if (!confirm(t('ce.confirm_delete'))) return
    try {
      await fetch(`/api/arms/claude-code/chat?sessionId=${sid}`, { method: 'DELETE' })
      if (activeSessionId === sid) newSession()
      fetchSessions()
    } catch {}
  }

  // Auto-resize textarea
  const autoResize = useCallback(() => {
    const el = inputRef.current
    if (!el) return
    el.style.height = 'auto'
    const maxH = 160 // ~6 lines
    el.style.height = `${Math.min(el.scrollHeight, maxH)}px`
    el.style.overflowY = el.scrollHeight > maxH ? 'auto' : 'hidden'
  }, [])

  // biome-ignore lint: auto-resize on input change
  useEffect(() => { autoResize() }, [input, autoResize])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const retry = () => {
    if (lastUserMessage) {
      setInput(lastUserMessage)
      inputRef.current?.focus()
    }
  }

  const selectedModelMeta = CODE_MODELS.find((m) => m.id === selectedModel) || CODE_MODELS[0]

  // ============ OFFLINE BRIDGE STATE ============
  if (!statusLoading && !bridgeStatus?.online) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-8">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-sm border border-zinc-100 p-10 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center mx-auto mb-5">
            <AlertTriangle className="w-7 h-7 text-amber-500" />
          </div>
          <h1 className="text-xl font-semibold text-zinc-900 mb-2">{t('ce.bridge_offline_title')}</h1>
          <p className="text-sm text-zinc-500 leading-relaxed mb-6">
            {t('ce.bridge_offline_desc')}
          </p>
          <div className="flex gap-2 justify-center">
            <Link href="/dashboard/hogar">
              <button className="px-5 py-2.5 rounded-full bg-zinc-900 text-white text-sm hover:bg-zinc-700 transition">
                {t('ce.install_bridge')}
              </button>
            </Link>
            <button
              onClick={fetchStatus}
              className="px-5 py-2.5 rounded-full border border-zinc-200 text-zinc-700 text-sm hover:bg-zinc-50 transition flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> {t('ce.retry')}
            </button>
          </div>
        </div>
      </div>
    )
  }

  // ============ MAIN ============
  // Activity feed: timeline of user questions + commands inferred from them
  const messagesNoSystem = messages.filter((m) => m.role !== 'system')
  const lastAssistant = [...messagesNoSystem].reverse().find((m) => m.role === 'assistant')
  const failedAssistant = lastAssistant?.status === 'failed' ? lastAssistant : null
  const streamingAssistant = messagesNoSystem.find((m) => m.role === 'assistant' && m.status === 'streaming')
  const streamingText = streamingAssistant?.content ? stripActionAndCodeFences(streamingAssistant.content) : ''

  // ─── Project Summary: detect multi-file creations rooted in the same folder ───
  // If user just created 2+ files under the same top-level folder, show a card
  // with the file tree and an "Abrir proyecto" CTA.
  const projectSummary = (() => {
    const completedWrites = commands.filter(
      (c) => c.status === 'completed' && c.type === 'write_file',
    )
    if (completedWrites.length < 2) return null
    const items: { path: string; root: string }[] = []
    for (const c of completedWrites) {
      try {
        const p = safeJsonParse(c.payload).path as string
        if (!p) continue
        const parts = p.replace(/\\/g, '/').split('/').filter(Boolean)
        if (parts.length < 2) continue
        items.push({ path: p, root: parts[0] })
      } catch {}
    }
    if (items.length < 2) return null
    // group by root
    const groups: Record<string, string[]> = {}
    for (const it of items) {
      if (!groups[it.root]) groups[it.root] = []
      groups[it.root].push(it.path)
    }
    // find largest group
    const sorted = Object.entries(groups).sort((a, b) => b[1].length - a[1].length)
    const [root, files] = sorted[0]
    if (files.length < 2) return null
    const hasHtml = files.some((f) => /\.html?$/i.test(f))
    const htmlFile = files.find((f) => /index\.html?$/i.test(f)) || files.find((f) => /\.html?$/i.test(f))
    return { root, files, hasHtml, htmlFile }
  })()

  return (
    <div className="h-[calc(100vh-5rem)] flex items-stretch justify-center px-4 py-4">
      <div className="w-full max-w-[1200px] flex bg-white rounded-3xl shadow-sm border border-zinc-100 overflow-hidden">

        {/* ===== LEFT NAV RAIL ===== */}
        <div className="w-[60px] flex-shrink-0 bg-white border-r border-zinc-100 flex flex-col items-center py-5 gap-3">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 flex items-center justify-center text-white shadow-sm">
            <span className="text-sm font-semibold">○</span>
          </div>
          <button
            onClick={() => setShowSessions((v) => !v)}
            title={t('ce.sessions')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition ${
              showSessions ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-400 hover:bg-zinc-50 hover:text-zinc-700'
            }`}
          >
            <Folder className="w-4 h-4" />
          </button>
          <button
            onClick={newSession}
            title={t('ce.new_session')}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-zinc-400 hover:bg-zinc-50 hover:text-zinc-700 transition"
          >
            <Plus className="w-4 h-4" />
          </button>
          <div className="flex-1" />
          <button
            onClick={() => setShowModelSelect((v) => !v)}
            title={t('ce.model')}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-zinc-400 hover:bg-zinc-50 hover:text-zinc-700 transition"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>

        {/* ===== SESSIONS DRAWER ===== */}
        <AnimatePresence initial={false}>
          {showSessions && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 240, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="flex-shrink-0 border-r border-zinc-100 overflow-hidden"
            >
              <div className="w-[240px] h-full p-3 flex flex-col">
                <div className="flex items-center justify-between mb-2 px-1">
                  <span className="text-[11px] uppercase tracking-[0.18em] text-zinc-400">{t('ce.sessions')}</span>
                  <button
                    onClick={newSession}
                    className="text-zinc-400 hover:text-zinc-700"
                    title={t('ce.new')}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto space-y-0.5">
                  {sessions.length === 0 && (
                    <div className="text-xs text-zinc-400 text-center py-6">{t('ce.no_sessions')}</div>
                  )}
                  {sessions.map((s) => (
                    <div
                      key={s.id}
                      onClick={() => setActiveSessionId(s.id)}
                      className={`group flex items-center gap-2 px-2 py-2 rounded-lg cursor-pointer text-sm transition ${
                        activeSessionId === s.id ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-600 hover:bg-zinc-50'
                      }`}
                    >
                      <span className="flex-1 truncate">{s.title}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          deleteSession(s.id)
                        }}
                        className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-rose-500 transition"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ===== CENTER: ACTIVITY FEED + INPUT ===== */}
        <div className="flex-1 flex flex-col min-w-0 border-r border-zinc-100">
          {/* status row */}
          <div className="px-7 pt-6 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-zinc-500">
              <span
                className={`inline-block w-2 h-2 rounded-full ${
                  bridgeStatus?.online ? 'bg-emerald-500' : 'bg-zinc-300'
                }`}
              />
              <span>{t('ce.header')}</span>
            </div>
            <div className="relative">
              <button
                onClick={() => setShowModelSelect((v) => !v)}
                className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1"
              >
                <span>{selectedModelMeta.providerIcon}</span>
                <span>{selectedModelMeta.name}</span>
                <ChevronDown className="w-3 h-3" />
              </button>
              <AnimatePresence>
                {showModelSelect && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="absolute right-0 top-full mt-2 w-72 bg-white border border-zinc-100 rounded-xl shadow-lg z-50 overflow-hidden"
                  >
                    <div className="max-h-80 overflow-y-auto py-1">
                      {CODE_MODELS.map((m) => (
                        <button
                          key={m.id}
                          onClick={() => {
                            setSelectedModel(m.id)
                            setShowModelSelect(false)
                          }}
                          className={`w-full flex items-start gap-2 px-3 py-2 text-left hover:bg-zinc-50 ${
                            selectedModel === m.id ? 'bg-zinc-50' : ''
                          }`}
                        >
                          <span className="text-base">{m.providerIcon}</span>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-zinc-900 truncate">{m.name}</div>
                            <div className="text-[10px] text-zinc-500 truncate">{m.description}</div>
                          </div>
                          {selectedModel === m.id && (
                            <Check className="w-3.5 h-3.5 text-zinc-700 mt-0.5" />
                          )}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* title / current question */}
          <div className="px-7 pb-2">
            <h1 className="text-2xl font-semibold text-zinc-900 leading-tight">
              {currentTitle}
            </h1>
          </div>

          {/* Execution Banner — OUTSIDE feed so it's always visible */}
          <div className="px-7">
            <ExecutionBanner
              commands={commands}
              isThinking={isThinking}
              streamingText={streamingText}
              t={t}
            />
          </div>

          {/* feed */}
          <div ref={feedRef} className="flex-1 overflow-y-auto px-7 pb-6 pt-1">
            {messagesNoSystem.length === 0 && commands.length === 0 ? (
              <div className="py-6">
                <div className="space-y-2">
                  {[
                    t('ce.suggestion_1'),
                    t('ce.suggestion_2'),
                    t('ce.suggestion_3'),
                  ].map((s) => (
                    <button
                      key={s}
                      onClick={() => setInput(s)}
                      className="w-full text-left text-sm text-zinc-500 px-4 py-3 rounded-xl bg-zinc-50 hover:bg-zinc-100 transition"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-1">

                {/* Current commands rendered as activity rows */}
                {commands.map((c, idx) => (
                  <ActivityRow
                    key={c.id}
                    command={c}
                    index={idx}
                    total={commands.length}
                    onConfirm={handleConfirm}
                    onReject={handleReject}
                    onSelect={setPreviewCmdId}
                    selected={previewCmdId === c.id}
                    onOpenPath={handleOpenPath}
                    onPreviewHtml={handlePreviewHtml}
                    t={t}
                  />
                ))}

                {/* Assistant text response — visible after completion (with or without commands) */}
                {lastAssistant && lastAssistant.content && lastAssistant.status !== 'streaming' && !isThinking && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-3 mx-1 p-4 rounded-2xl bg-zinc-50/60 border border-zinc-100"
                  >
                    <div
                      className="prose-sm max-w-none text-zinc-700 leading-relaxed text-[14px]"
                      dangerouslySetInnerHTML={{ __html: tinyMarkdown(stripActionAndCodeFences(lastAssistant.content)) }}
                    />
                  </motion.div>
                )}

                {/* Project summary — shown when 2+ files were created in the same root folder */}
                {projectSummary && !isThinking && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    className="mt-5 mx-1 p-5 rounded-2xl bg-zinc-50/80 border border-zinc-100"
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-base leading-none mt-0.5">✅</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-zinc-900">
                          {t('ce.project_created')}
                        </div>
                        <div className="mt-3 font-mono text-[13px] text-zinc-600 leading-relaxed">
                          <div className="text-zinc-800">📁 {projectSummary.root}/</div>
                          {projectSummary.files.map((f, i) => {
                            const isLast = i === projectSummary.files.length - 1;
                            return (
                              <div key={f} className="pl-2">
                                <span className="text-zinc-400">{isLast ? '└──' : '├──'}</span>{' '}
                                <span>{f}</span>
                              </div>
                            );
                          })}
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          <button
                            onClick={() => handleOpenPath(projectSummary.root)}
                            className="text-xs px-3 py-1.5 rounded-full bg-zinc-900 text-white hover:bg-zinc-700 transition flex items-center gap-1.5"
                          >
                            <span>📁</span> {t('ce.chip_open_folder')}
                          </button>
                          {projectSummary.hasHtml && projectSummary.htmlFile && (
                            <>
                              <button
                                onClick={() => {
                                  const cmd = commands.find((c) => {
                                    if (c.type !== 'write_file' || c.status !== 'completed') return false;
                                    try {
                                      const p = safeJsonParse(c.payload).path as string;
                                      return p === projectSummary.htmlFile;
                                    } catch {
                                      return false;
                                    }
                                  });
                                  if (cmd) handlePreviewHtml(cmd.id);
                                }}
                                className="text-xs px-3 py-1.5 rounded-full bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 transition flex items-center gap-1.5"
                              >
                                <span>◉</span> {t('ce.chip_preview')}
                              </button>
                              <button
                                onClick={() => projectSummary.htmlFile && handleOpenPath(projectSummary.htmlFile)}
                                className="text-xs px-3 py-1.5 rounded-full bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 transition flex items-center gap-1.5"
                              >
                                <span>↗</span> {t('ce.chip_open_browser')}
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Friendly failure with retry */}
                {failedAssistant && !isThinking && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 mx-1 p-4 rounded-2xl bg-rose-50 border border-rose-100"
                  >
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="text-sm text-zinc-800">
                          {t('ce.error_action')}
                        </div>
                        <div className="text-xs text-zinc-500 mt-0.5">
                          {sanitizeError(failedAssistant.error || '')}
                        </div>
                        <button
                          onClick={retry}
                          className="mt-3 text-xs px-3 py-1 rounded-full bg-zinc-900 text-white hover:bg-zinc-700 transition"
                        >
                          {t('ce.retry')}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Optional details (assistant prose) */}
                {messagesNoSystem.length > 0 && (
                  <div className="mt-4 mx-1">
                    <button
                      onClick={() => setShowDetails((v) => !v)}
                      className="text-xs text-zinc-400 hover:text-zinc-700 flex items-center gap-1"
                    >
                      {showDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      {showDetails ? t('ce.hide_details') : t('ce.show_details')}
                    </button>
                    {showDetails && (
                      <div className="mt-2 space-y-3">
                        {messagesNoSystem.map((m) => (
                          <div key={m.id} className="text-sm">
                            <div className="text-[10px] uppercase tracking-[0.18em] text-zinc-400 mb-1">
                              {m.role === 'user' ? t('ce.role_user') : t('ce.role_assistant')}
                            </div>
                            <div
                              className="text-zinc-700 leading-relaxed"
                              dangerouslySetInnerHTML={{
                                __html: tinyMarkdown(
                                  stripActionAndCodeFences(m.content),
                                ),
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Smart Textarea capsule */}
          <div className="px-7 pb-6 pt-3">
            <div className="flex items-end gap-3 bg-[#F9F9F9] border border-zinc-200 rounded-2xl px-4 py-3 shadow-sm focus-within:border-zinc-400 focus-within:shadow-md transition-all">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                placeholder={t('ce.placeholder')}
                disabled={sending || !bridgeStatus?.online}
                className="flex-1 resize-none outline-none bg-transparent text-[15px] leading-relaxed text-zinc-900 placeholder:text-zinc-400 py-0.5 scrollbar-thin scrollbar-thumb-zinc-300"
                style={{ minHeight: '26px' }}
              />
              <button
                onClick={sendMessage}
                disabled={sending || !input.trim() || !bridgeStatus?.online}
                className="flex-shrink-0 px-4 py-1.5 rounded-full bg-zinc-900 text-white text-xs font-medium hover:bg-zinc-700 disabled:opacity-30 transition-all flex items-center gap-1.5 mb-0.5"
              >
                {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                {t('ce.ask')}
              </button>
            </div>
            <div className="text-[10px] text-zinc-400 mt-2 px-2 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Shield className="w-3 h-3" />
                {t('ce.sandbox_notice')}
              </span>
              <span className="text-zinc-300">{t('ce.shift_enter_hint')}</span>
            </div>
          </div>
        </div>

        {/* ===== RIGHT: PREVIEW / WORKSPACE PANE (Zen Mode expandable) ===== */}
        <div
          className={`flex flex-col bg-zinc-50/50 transition-all duration-200 ease-out ${
            previewExpanded
              ? 'fixed inset-0 z-[9999] bg-white'
              : 'w-[380px] flex-shrink-0'
          }`}
        >
          {/* Tab switcher + actions */}
          <div className={`px-5 py-3 flex items-center gap-1 border-b ${previewExpanded ? 'border-zinc-200 bg-zinc-50/90' : 'border-zinc-100'}`}>
            {/* In expanded mode, hide tabs — show file info instead */}
            {previewExpanded ? (
              <div className="flex items-center gap-3">
                <span className="text-[13px] font-medium text-zinc-700">
                  {projectPreview ? t('ce.project_preview') : t('ce.preview')}
                </span>
                {previewCmd && (
                  <span className="text-xs text-zinc-400 font-mono">
                    {safeJsonParse(previewCmd.payload).path || ''}
                  </span>
                )}
                {isExecutingAny && (
                  <span className="inline-flex items-center gap-1.5 text-[10px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    {t('ce.preview_updating')}
                  </span>
                )}
              </div>
            ) : (
              <>
                <button
                  onClick={() => setRightTab('preview')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] uppercase tracking-[0.14em] transition ${
                    rightTab === 'preview' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                  }`}
                >
                  <Eye className="w-3 h-3" /> {t('ce.preview')}
                  {isExecutingAny && rightTab === 'preview' && (
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                  )}
                </button>
                <button
                  onClick={() => { setRightTab('workspace'); fetchWorkspace(); fetchRecentChanges() }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] uppercase tracking-[0.14em] transition ${
                    rightTab === 'workspace' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                  }`}
                >
                  <FolderTree className="w-3 h-3" /> Workspace
                  {workspace?.indexed && (
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 ml-0.5" />
                  )}
                </button>
              </>
            )}
            <div className="flex-1" />
            {/* Preview action buttons — visible in both modes */}
            {(rightTab === 'preview' || previewExpanded) && (
              <div className="flex items-center gap-1">
                {/* Project toggle (multi-file) */}
                {previewExpanded && commands.filter((c) => c.type === 'write_file' && c.status === 'completed').length >= 2 && (
                  <button
                    onClick={() => setProjectPreview((v) => !v)}
                    className={`text-[11px] px-2.5 py-1 rounded-md border transition font-medium ${
                      projectPreview
                        ? 'bg-zinc-900 text-white border-zinc-900'
                        : 'border-zinc-200 text-zinc-500 hover:border-zinc-400'
                    }`}
                  >
                    {projectPreview ? t('ce.single_file') : t('ce.project_view')}
                  </button>
                )}
                {/* Refresh preview */}
                <button
                  onClick={() => setPreviewRefreshKey((k) => k + 1)}
                  className={`rounded-lg flex items-center justify-center text-zinc-400 hover:text-zinc-700 hover:bg-white transition ${previewExpanded ? 'w-8 h-8' : 'w-7 h-7'}`}
                  title={t('ce.preview_refresh')}
                >
                  <RotateCw className={previewExpanded ? 'w-3.5 h-3.5' : 'w-3 h-3'} />
                </button>
                {/* Open in browser */}
                {livePreviewUrl && (
                  <a
                    href={livePreviewUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`rounded-lg flex items-center justify-center text-zinc-400 hover:text-zinc-700 hover:bg-white transition ${previewExpanded ? 'w-8 h-8' : 'w-7 h-7'}`}
                    title={t('ce.preview_open_browser')}
                  >
                    <ExternalLink className={previewExpanded ? 'w-3.5 h-3.5' : 'w-3 h-3'} />
                  </a>
                )}
                {/* Expand / Collapse toggle */}
                <button
                  onClick={() => setPreviewExpanded((v) => !v)}
                  className={`rounded-md flex items-center justify-center gap-1.5 transition text-[10px] font-medium ${
                    previewExpanded
                      ? 'h-8 px-3 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
                      : 'h-7 px-2.5 text-zinc-500 hover:text-zinc-900 bg-white hover:bg-zinc-100 border border-zinc-200 hover:border-zinc-300'
                  }`}
                  title={previewExpanded ? 'ESC' : t('ce.preview_expand')}
                >
                  {previewExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">{previewExpanded ? 'ESC' : 'Expand'}</span>
                </button>
                {/* Close X — only in expanded */}
                {previewExpanded && (
                  <button
                    onClick={() => setPreviewExpanded(false)}
                    className="ml-0.5 w-8 h-8 rounded-md flex items-center justify-center text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition"
                    title="Close (ESC)"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}
          </div>

          {(rightTab === 'preview' || previewExpanded) ? (
            <>
              {/* Sub-header: file counter + project toggle — hidden in Zen mode */}
              {!previewExpanded && (
                <div className="px-5 py-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {previewCmd && !projectPreview && (
                      <span className="text-[10px] text-zinc-400">
                        {commands.findIndex((c) => c.id === previewCmd.id) + 1} / {commands.length}
                      </span>
                    )}
                    {projectPreview && (
                      <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                        <Eye className="w-3 h-3" /> {t('ce.project_preview')}
                      </span>
                    )}
                  </div>
                  {commands.filter((c) => c.type === 'write_file' && c.status === 'completed').length >= 2 && (
                    <button
                      onClick={() => setProjectPreview((v) => !v)}
                      className={`text-[10px] px-2.5 py-1 rounded-full border transition ${
                        projectPreview
                          ? 'bg-zinc-900 text-white border-zinc-900'
                          : 'border-zinc-200 text-zinc-500 hover:border-zinc-400'
                      }`}
                    >
                      {projectPreview ? t('ce.single_file') : t('ce.project_view')}
                    </button>
                  )}
                </div>
              )}
              {/* Preview content area */}
              <div className={`flex-1 min-h-0 relative ${previewExpanded ? 'p-0' : 'px-5 pb-5'}`}>
                {/* Updating overlay */}
                {isExecutingAny && (
                  <div className={`absolute z-10 flex items-center justify-center bg-white/70 backdrop-blur-[2px] pointer-events-none ${previewExpanded ? 'inset-0' : 'inset-x-5 inset-y-0 rounded-2xl'}`}>
                    <div className="flex flex-col items-center gap-2">
                      <div className="relative">
                        <div className="w-8 h-8 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                      </div>
                      <span className="text-[11px] font-medium text-amber-600">{t('ce.preview_updating')}</span>
                    </div>
                  </div>
                )}
                <div className={`h-full overflow-auto ${previewExpanded ? 'bg-white' : 'bg-white rounded-2xl border border-zinc-100 p-4'}`}>
                  <PreviewPanel command={previewCmd} commands={commands} projectMode={projectPreview} refreshKey={previewRefreshKey} t={t} />
                </div>
              </div>
              {/* Status bar — hidden in Zen mode */}
              {!previewExpanded && (
                <div className="px-5 pb-3 text-[10px] text-zinc-400 text-center flex items-center justify-center gap-1.5">
                  {isThinking && <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />}
                  {isThinking ? t('ce.status_live') : t('ce.status_idle')}
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 overflow-y-auto px-5 pb-5">
              {!workspace?.indexed ? (
                <div className="flex flex-col items-center justify-center h-full text-center py-12">
                  <FolderTree className="w-8 h-8 text-zinc-300 mb-3" />
                  <p className="text-sm text-zinc-500 mb-1">{t('ce.ws_not_indexed')}</p>
                  <p className="text-xs text-zinc-400">{t('ce.ws_not_indexed_hint')}</p>
                </div>
              ) : (
                <div className="space-y-4 pt-2">
                  {/* Stats bar */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-50 text-emerald-700 text-[10px] font-medium">
                      <Zap className="w-3 h-3" /> {t('ce.ws_context_active')}
                    </span>
                    <span className="text-[10px] text-zinc-400">
                      {workspace.fileCount} {t('ce.ws_files')} · {formatSizeUI(workspace.totalSize || 0)}
                    </span>
                  </div>

                  {/* Recent external changes */}
                  {recentChanges.length > 0 && (
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.14em] text-zinc-400 mb-2">{t('ce.ws_recent_changes')}</div>
                      <div className="space-y-1">
                        {recentChanges.slice(0, 10).map((c) => (
                          <div key={c.id} className="flex items-center gap-2 py-1 px-2 rounded-lg hover:bg-white transition">
                            <span className="text-xs">
                              {c.eventType === 'create' ? '🆕' : c.eventType === 'modify' ? '✏️' : c.eventType === 'delete' ? '🗑️' : '🔄'}
                            </span>
                            <span className="text-xs text-zinc-700 truncate flex-1">{c.filePath}</span>
                            <span className="text-[9px] text-zinc-400 flex-shrink-0">
                              {new Date(c.detectedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* File tree */}
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.14em] text-zinc-400 mb-2">{t('ce.ws_file_tree')}</div>
                    <div className="bg-white rounded-xl border border-zinc-100 overflow-hidden">
                      <div className="max-h-[400px] overflow-y-auto py-1">
                        {(workspace.tree || []).slice(0, 100).map((f) => (
                          <div
                            key={f.path}
                            className="flex items-center gap-2 px-3 py-1.5 hover:bg-zinc-50 transition"
                            style={{ paddingLeft: `${Math.min((f.path.split('/').length - 1) * 12 + 12, 60)}px` }}
                          >
                            {f.isDir ? (
                              <FolderOpen className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                            ) : (
                              <FileText className="w-3.5 h-3.5 text-zinc-400 flex-shrink-0" />
                            )}
                            <span className="text-xs text-zinc-700 truncate flex-1">
                              {f.path.split('/').pop()}
                            </span>
                            {!f.isDir && f.size > 0 && (
                              <span className="text-[9px] text-zinc-400 flex-shrink-0">{formatSizeUI(f.size)}</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Scan info */}
                  <div className="text-[10px] text-zinc-400 text-center pt-2">
                    {t('ce.ws_last_scan')}: {workspace.lastScanAt ? new Date(workspace.lastScanAt).toLocaleTimeString() : '—'}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

      </div>


    </div>
  )
}

// strip both octopus-action JSON fences, code fences, and raw unfenced JSON actions from prose
function stripActionAndCodeFences(content: string): string {
  let out = content.replace(/```\s*octopus-action\s*\n[\s\S]*?```/g, '')
  out = out.replace(/```[\w-]*\s*\n[\s\S]*?```/g, '[code]')
  // Strip raw (unfenced) JSON blocks containing "actions" array
  const actionsIdx = out.indexOf('"actions"')
  if (actionsIdx > 0) {
    // Find the opening { before "actions"
    let openBrace = -1
    for (let i = actionsIdx - 1; i >= 0; i--) {
      if (out[i] === '{') { openBrace = i; break }
      if (out[i] !== ' ' && out[i] !== '\n' && out[i] !== '\r' && out[i] !== '\t') break
    }
    if (openBrace >= 0) {
      let depth = 0; let inStr = false; let esc = false; let closeIdx = -1
      for (let i = openBrace; i < out.length; i++) {
        const ch = out[i]
        if (esc) { esc = false; continue }
        if (ch === '\\' && inStr) { esc = true; continue }
        if (ch === '"' && !esc) { inStr = !inStr; continue }
        if (inStr) continue
        if (ch === '{') depth++
        else if (ch === '}') { depth--; if (depth === 0) { closeIdx = i; break } }
      }
      if (closeIdx > openBrace) {
        out = out.slice(0, openBrace) + out.slice(closeIdx + 1)
      }
    }
  }
  return out.trim()
}

function formatSizeUI(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)}KB`
  return `${(bytes / 1048576).toFixed(1)}MB`
}
