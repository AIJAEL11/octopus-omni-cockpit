import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

// ═══════════════════════════════════════════════════════════════════════════════
// Bridge POSTs results here after executing a command.
// Supports two modes:
//   1. Final result:  { commandId, status: 'completed'|'failed', result?, error? }
//   2. Stream chunk:  { commandId, action: 'stream', chunk: string }
//      → Appends stdout/stderr to streamOutput field (terminal streaming)
// ═══════════════════════════════════════════════════════════════════════════════
async function validateBridgeToken(token: string): Promise<string | null> {
  if (!token) return null
  const apiKey = await prisma.apiKey.findFirst({
    where: {
      apiKey: token,
      OR: [{ serviceType: 'hogar_bridge' }, { serviceType: 'octopus_bridge' }],
    },
  })
  return apiKey?.userId || null
}

export async function POST(req: NextRequest) {
  const token = req.headers.get('x-bridge-token') || ''
  const userId = await validateBridgeToken(token)
  if (!userId) {
    return NextResponse.json({ error: 'Invalid bridge token' }, { status: 401 })
  }

  let body: {
    commandId: string
    action?: 'stream'
    chunk?: string
    status?: 'completed' | 'failed'
    result?: unknown
    error?: string
  }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  const { commandId } = body
  if (!commandId) {
    return NextResponse.json({ error: 'commandId is required' }, { status: 400 })
  }

  // ── Stream chunk mode ──────────────────────────────────────────────────
  if (body.action === 'stream' && body.chunk) {
    const cmd = await prisma.bridgeCommand.findFirst({
      where: {
        id: commandId,
        session: { userId },
        status: 'executing',
      },
      select: { id: true, streamOutput: true },
    })
    if (!cmd) {
      return NextResponse.json({ error: 'Command not found or not executing' }, { status: 404 })
    }

    // Append chunk (cap at 500KB total to prevent unbounded growth)
    const prev = cmd.streamOutput || ''
    const newOutput = (prev + body.chunk).slice(-500_000)
    await prisma.bridgeCommand.update({
      where: { id: commandId },
      data: { streamOutput: newOutput },
    })

    return NextResponse.json({ ok: true })
  }

  // ── Final result mode ──────────────────────────────────────────────────
  const { status, result, error } = body
  if (!status) {
    return NextResponse.json({ error: 'status is required' }, { status: 400 })
  }

  // Verify ownership — also accept re-sync for 'executing' commands that went offline
  const cmd = await prisma.bridgeCommand.findFirst({
    where: {
      id: commandId,
      session: { userId },
      status: { in: ['executing', 'approved', 'pending'] },
    },
  })
  if (!cmd) {
    // Might be a re-sync for an already-reported command — accept silently
    const existing = await prisma.bridgeCommand.findFirst({
      where: { id: commandId, session: { userId } },
      select: { status: true },
    })
    if (existing && (existing.status === 'completed' || existing.status === 'failed')) {
      return NextResponse.json({ ok: true, resync: true })
    }
    return NextResponse.json({ error: 'Command not found or not pending' }, { status: 404 })
  }

  // Truncate huge results to 200KB max
  const resultStr = result !== undefined ? JSON.stringify(result).substring(0, 200000) : null

  await prisma.bridgeCommand.update({
    where: { id: commandId },
    data: {
      status,
      result: resultStr,
      error: error ? error.substring(0, 1000) : null,
    },
  })

  return NextResponse.json({ ok: true })
}
