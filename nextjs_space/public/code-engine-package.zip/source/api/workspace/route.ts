import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

// ═══════════════════════════════════════════════════════════════════════════════
// WORKSPACE INTELLIGENCE API
// POST — Bridge reports workspace index (full scan) or file change events
// GET  — Frontend/LLM queries the workspace index and recent changes
// ═══════════════════════════════════════════════════════════════════════════════

async function validateBridgeToken(token: string): Promise<string | null> {
  if (!token) return null
  const apiKey = await prisma.apiKey.findFirst({
    where: {
      apiKey: token,
      OR: [{ serviceType: 'hogar_bridge' }, { serviceType: 'octopus_bridge' }],
    },
  })
  return apiKey?.userId || null
}

// ── POST — Bridge reports index or file changes ──────────────────────────────
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-bridge-token') || ''
  const userId = await validateBridgeToken(token)
  if (!userId) {
    return NextResponse.json({ error: 'Invalid bridge token' }, { status: 401 })
  }

  let body: {
    action: 'full_scan' | 'file_changes'
    // full_scan fields
    fileTree?: Array<{ path: string; isDir: boolean; size: number; modifiedAt?: string }>
    fileCount?: number
    totalSize?: number
    rootPath?: string
    // file_changes fields
    changes?: Array<{
      eventType: 'create' | 'modify' | 'delete' | 'rename'
      filePath: string
      fileSize?: number
      isDir?: boolean
    }>
  }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  // ── Full workspace scan ──────────────────────────────────────────────────
  if (body.action === 'full_scan') {
    const tree = body.fileTree || []
    const fileCount = body.fileCount ?? tree.length
    const totalSize = body.totalSize ?? 0
    const rootPath = body.rootPath || ''

    // Cap tree size (max 100KB JSON) to avoid bloating DB
    const treeJson = JSON.stringify(tree).slice(0, 100_000)

    await prisma.workspaceIndex.upsert({
      where: { userId },
      create: {
        userId,
        fileTree: treeJson,
        fileCount,
        totalSize,
        rootPath,
        lastScanAt: new Date(),
      },
      update: {
        fileTree: treeJson,
        fileCount,
        totalSize,
        rootPath,
        lastScanAt: new Date(),
      },
    })

    return NextResponse.json({ ok: true, indexed: fileCount })
  }

  // ── File change events ───────────────────────────────────────────────────
  if (body.action === 'file_changes' && body.changes) {
    const changes = body.changes.slice(0, 50) // max 50 events per batch

    // Batch insert change events
    await prisma.fileChangeEvent.createMany({
      data: changes.map((c) => ({
        userId,
        eventType: c.eventType,
        filePath: c.filePath,
        fileSize: c.fileSize ?? null,
        isDir: c.isDir ?? false,
      })),
    })

    // Also update the workspace index tree incrementally
    const index = await prisma.workspaceIndex.findUnique({ where: { userId } })
    if (index) {
      try {
        const tree: Array<{ path: string; isDir: boolean; size: number }> = JSON.parse(index.fileTree)
        for (const change of changes) {
          if (change.eventType === 'delete') {
            // Remove from tree
            const idx = tree.findIndex((f) => f.path === change.filePath)
            if (idx >= 0) tree.splice(idx, 1)
          } else if (change.eventType === 'create') {
            // Add to tree if not exists
            if (!tree.some((f) => f.path === change.filePath)) {
              tree.push({ path: change.filePath, isDir: change.isDir ?? false, size: change.fileSize ?? 0 })
            }
          } else if (change.eventType === 'modify') {
            // Update size
            const existing = tree.find((f) => f.path === change.filePath)
            if (existing) {
              existing.size = change.fileSize ?? existing.size
            }
          }
        }
        const treeJson = JSON.stringify(tree).slice(0, 100_000)
        await prisma.workspaceIndex.update({
          where: { userId },
          data: { fileTree: treeJson, fileCount: tree.length, lastScanAt: new Date() },
        })
      } catch {
        // If tree JSON is corrupted, ignore incremental update
      }
    }

    return NextResponse.json({ ok: true, processed: changes.length })
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
}

// ── GET — Frontend/LLM queries workspace index and changes ───────────────────
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action') || 'index'

  // Return workspace index
  if (action === 'index') {
    const index = await prisma.workspaceIndex.findUnique({
      where: { userId: session.user.id },
      select: {
        fileTree: true,
        fileCount: true,
        totalSize: true,
        rootPath: true,
        lastScanAt: true,
      },
    })
    if (!index) {
      return NextResponse.json({ indexed: false })
    }
    let tree: unknown[] = []
    try { tree = JSON.parse(index.fileTree) } catch {}
    return NextResponse.json({
      indexed: true,
      fileCount: index.fileCount,
      totalSize: index.totalSize,
      rootPath: index.rootPath,
      lastScanAt: index.lastScanAt,
      tree,
    })
  }

  // Return recent file changes
  if (action === 'changes') {
    const since = searchParams.get('since')
    const sinceDate = since ? new Date(since) : new Date(Date.now() - 60 * 60 * 1000) // last hour
    const changes = await prisma.fileChangeEvent.findMany({
      where: {
        userId: session.user.id,
        detectedAt: { gte: sinceDate },
      },
      orderBy: { detectedAt: 'desc' },
      take: 100,
    })
    return NextResponse.json({ changes })
  }

  // Return context summary for LLM injection
  if (action === 'context') {
    const index = await prisma.workspaceIndex.findUnique({
      where: { userId: session.user.id },
    })
    if (!index) {
      return NextResponse.json({ context: null })
    }
    let tree: Array<{ path: string; isDir: boolean; size: number }> = []
    try { tree = JSON.parse(index.fileTree) } catch {}

    // Build a compact text summary for LLM context
    const dirs = tree.filter((f) => f.isDir).map((f) => f.path)
    const files = tree.filter((f) => !f.isDir)
    // Group files by extension
    const extGroups: Record<string, number> = {}
    for (const f of files) {
      const ext = f.path.split('.').pop()?.toLowerCase() || 'other'
      extGroups[ext] = (extGroups[ext] || 0) + 1
    }

    // Recent changes (last 30 min)
    const recentChanges = await prisma.fileChangeEvent.findMany({
      where: {
        userId: session.user.id,
        detectedAt: { gte: new Date(Date.now() - 30 * 60 * 1000) },
      },
      orderBy: { detectedAt: 'desc' },
      take: 20,
    })

    const contextLines: string[] = [
      `WORKSPACE: ${index.rootPath}`,
      `Files: ${index.fileCount} | Size: ${formatBytes(index.totalSize)}`,
      `Last scan: ${index.lastScanAt.toISOString()}`,
      '',
      'Structure:',
      ...dirs.slice(0, 30).map((d) => `  📁 ${d}/`),
      ...files.slice(0, 50).map((f) => `  📄 ${f.path} (${formatBytes(f.size)})`),
      '',
      `Extensions: ${Object.entries(extGroups).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => `.${k}:${v}`).join(' ')}`,
    ]

    if (recentChanges.length > 0) {
      contextLines.push('', 'Recent external changes (last 30 min):')
      for (const c of recentChanges) {
        const icon = c.eventType === 'create' ? '🆕' : c.eventType === 'modify' ? '✏️' : c.eventType === 'delete' ? '🗑️' : '🔄'
        contextLines.push(`  ${icon} ${c.eventType}: ${c.filePath}`)
      }
    }

    return NextResponse.json({ context: contextLines.join('\n') })
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)}KB`
  return `${(bytes / 1048576).toFixed(1)}MB`
}
