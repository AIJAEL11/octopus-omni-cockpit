# 🐙 Code Engine — Changelog & Known Issues

## Current Version: 2.0 (April 2026)

---

## ✅ Recent Fixes

### Truncated Action Parsing (Apr 2026)
- **Problem**: LLM generated 20K+ char responses that hit token limit before closing `octopus-action` fence → 0 actions parsed → blank preview
- **Fix**: Added `TRUNCATED_FENCE_REGEX` + `extractCompleteActions()` with brace-counting to recover complete action objects from truncated responses
- **Also**: Increased `maxTokens` from 8,000 to 16,000
- **Also**: Updated system prompt to require multi-file splitting (HTML/CSS/JS separate)

### Preview V2 "Zen Mode" (Apr 2026)
- **Problem**: Portal-based fullscreen created a second iframe → content reload, double rendering
- **Fix**: Replaced with CSS-only expansion (`fixed inset-0 z-[9999]`), same iframe expands, zero reload
- **Removed**: `FullscreenPortal`, `FullscreenPreviewPanel`, `createPortal` import, `<style>` keyframes

### Real-Time Architecture (Apr 2026)
- **Previous**: Client polled `/api/arms/claude-code/chat?action=commands` every N seconds
- **Now**: SSE stream endpoint (`/stream`) pushes command updates in real-time
- Added `streamOutput` field to `BridgeCommand` for terminal streaming
- Bridge uses long-polling (25s hold) instead of short polls

---

## 🐛 Known Issues / Areas for Improvement

### 1. Preview Panel — Core Issue
- **Problem**: When the LLM generates HTML that references external CSS/JS files via relative paths (`<link href="style.css">`), the iframe's `srcDoc` can't resolve them because there's no server serving those files
- **Current workaround**: `ProjectPreview` concatenates all CSS inline and all JS inline into one mega-HTML document
- **Ideal fix**: A local preview server (similar to VS Code Live Preview) that actually serves the files from the workspace

### 2. Large File Content in Preview
- Very large HTML files (10K+) can make the iframe sluggish
- No virtual scrolling for code preview

### 3. No Syntax Highlighting Library
- Code is displayed with basic `<pre>` styling
- Could benefit from Prism.js, Shiki, or CodeMirror for proper highlighting

### 4. Session Panel UX
- Session list is basic (just titles)
- No search, no grouping, no favorite sessions

### 5. Model Selector
- Works but could be more visual (show provider icons, tier badges)

### 6. Workspace Panel
- File tree is flat list, not a proper tree view
- No file search within workspace
- No file content preview from workspace panel

### 7. Mobile Responsiveness
- 3-column layout doesn't work on mobile
- No responsive breakpoints implemented

---

## 🚀 Feature Wishlist

1. **Split-pane editor** — Show code on left, preview on right with live sync
2. **File tabs** — Open multiple files like a real IDE
3. **Diff view** — Show what changed when a file is modified
4. **Terminal panel** — Full terminal emulator in the preview area
5. **Drag & drop** — Upload files to workspace by dragging into the panel
6. **Theme toggle** — Light/dark mode for the Code Engine specifically
7. **Command palette** — Cmd+K to quick-search actions, files, sessions
8. **Preview device frames** — Show preview in iPhone/iPad/Desktop frames
9. **Collaborative editing** — Multiple users editing the same workspace
10. **Git integration** — Show git status, branches, commits in workspace panel

---

## 📊 Metrics

| Metric | Value |
|--------|-------|
| Total lines of code | ~4,058 |
| Frontend (page.tsx) | 2,455 lines |
| API routes | 1,188 lines |
| Lib (prompts/parser) | 415 lines |
| Prisma models | 5 models |
| i18n keys | 97 (ES) + 97 (EN) = 194 |
| API endpoints | 10 (7 routes × GET/POST/DELETE) |
