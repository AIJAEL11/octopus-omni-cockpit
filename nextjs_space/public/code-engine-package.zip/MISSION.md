# 🎯 Mission: Create the Most Epic Code Engine Portal

## Context
You are redesigning the **Code Engine** module for **Octopus Omni Cockpit** (octopuskills.com) — an AI-powered SaaS platform for marketing automation.

The Code Engine is a "Code IDE" that connects to the user's local machine via a desktop bridge app. The user types a prompt, the AI generates code, and the bridge executes it on their machine in real-time.

## Current State
See `screenshots/current-ui.png` for what we have now. It works but is basic.

## Your Mission
**Design and build the most epic, professional, visually stunning Code Engine portal possible.**

Think:
- **Cursor IDE** level polish
- **VS Code** functionality
- **Apple** aesthetic minimalism
- **Linear** smooth animations

## Design Principles
1. **"Peace, not complexity"** — Clean, calm, no clutter
2. **White-first** with strategic color accents
3. **Smooth transitions** everywhere (Framer Motion)
4. **Professional** — This should look like a $100M product
5. **Responsive** — Must work on different screen sizes

## What You Can Change
- ✅ The entire frontend (`page.tsx`) — go wild
- ✅ Add animations, transitions, micro-interactions
- ✅ Redesign the layout (but keep 3-zone: sessions/chat/preview)
- ✅ Add new UI features (file tabs, split panes, command palette, etc.)
- ✅ Add new i18n keys (prefixed with `ce.`)
- ✅ Improve the preview system
- ✅ Add syntax highlighting
- ✅ Add keyboard shortcuts

## What You CANNOT Change
- ❌ API route URLs (Bridge depends on exact paths)
- ❌ API request/response shapes (Bridge is a separate app)
- ❌ Prisma schema field names (DB has existing data)
- ❌ The `x-bridge-token` auth mechanism
- ❌ Shared library function signatures (`@/lib/*`)

## Technical Constraints
- React 18 + Next.js 14 (App Router)
- Tailwind CSS only (no CSS modules, no styled-components)
- Framer Motion for animations
- Lucide React for icons
- No external UI libraries (no shadcn/ui, no Radix, no MUI)
- All text via `t('ce.key')` for i18n support
- `'use client'` directive required

## Deliverables
Return the same file structure:
```
source/
  frontend/page.tsx          ← Redesigned frontend
  api/chat/route.ts          ← Can improve, don't break contracts
  api/poll/route.ts          ← Probably no changes needed
  api/respond/route.ts       ← Probably no changes needed  
  api/confirm/route.ts       ← Probably no changes needed
  api/open/route.ts          ← Probably no changes needed
  api/stream/route.ts        ← Can improve for new features
  api/workspace/route.ts     ← Can improve for new features
  lib/claude-code-prompts.ts ← Can improve parser/prompt
```

Plus a `NEW_I18N_KEYS.md` file listing any new translation keys added (with ES and EN values).

## Quality Bar
If someone opens this and says "wow, this looks like Cursor" — you've succeeded.
If it looks like a basic CRUD app — try again.
