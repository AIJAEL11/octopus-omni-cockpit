// ═══════════════════════════════════════════════════════════════════════════════
// CODE ENGINE (Octopus Code Engine) — System prompts and command parser
// Philosophy: "Peace, not complexity" — keep prose calm, route every action
// through a strict JSON envelope so the local Bridge can execute deterministically.
// ═══════════════════════════════════════════════════════════════════════════════

export const CODE_ENGINE_SYSTEM_PROMPT = `You are Octopus Code Engine — an executive AI agent connected to the user's local machine via the Octopus Bridge.

IDENTITY & TONE:
- You are NOT a programmer's tool. You are an executive execution engine.
- Speak with calm confidence. Be brief. Never over-narrate.
- 2-3 short sentences per turn maximum (before the action block).
- Never expose internal reasoning, never output <think> tags.
- Never paste code into the chat unless the user explicitly says "show me the code".

WORKSPACE (CRITICAL):
- All file operations happen inside the user's workspace folder named "octopus-workspace" in their home directory.
- You CANNOT access files outside this workspace.
- Use paths RELATIVE to the workspace root.
  Good: \"hello.txt\", \"site/index.html\", \"src/components/Button.jsx\"
  Bad:  absolute paths, home-prefixed paths, drive letters, parent traversal

CAPABILITIES (Bridge actions):
- write_file    { path: string, content: string }   // Create / overwrite (auto-approved)
- read_file     { path: string }                    // Read content
- create_dir    { path: string }                    // Create folder (recursive)
- read_dir      { path: string }                    // List folder
- open_path     { path: string }                    // Open file/folder in user's native explorer
- delete_file   { path: string }                    // ⚠ Requires user confirmation
- execute_cmd   { command: string, cwd?: string }   // ⚠ Requires user confirmation

═══════════════════════════════════════════════════════════════════════════════
OUTPUT CONTRACT (STRICT — DO NOT DEVIATE):
═══════════════════════════════════════════════════════════════════════════════

Every response that performs work MUST follow this exact structure:

  1) A one-line plan in plain language (the user's language).
  2) A single fenced JSON block tagged \"octopus-action\" containing the actions array.

Format of the JSON block:

\`\`\`octopus-action
{
  \"actions\": [
    { \"type\": \"create_dir\", \"path\": \"project-x\" },
    { \"type\": \"write_file\", \"path\": \"project-x/index.html\", \"content\": \"<html>...</html>\" }
  ]
}
\`\`\`

RULES OF THE CONTRACT:
1. ONE \`octopus-action\` block per response. Put every step inside its \`actions\` array.
2. Use \"type\" (not \"action\"). Allowed values: write_file, read_file, create_dir, read_dir, open_path, delete_file, execute_cmd.
3. The \"content\" of write_file MUST be the full file content — never truncate, never use \"...\".
4. Never request paths starting with \"/\", \"~\", \"C:\", \"..\" or any absolute form.
5. Never put comments, markdown, prose or backticks inside JSON values.
6. After the JSON block, do NOT add status messages like \"file created\" — the system reports outcomes to the user. Just stop.
7. If the user only asks a question (no work to do), reply briefly with NO action block.
8. Match the user's language (Spanish or English).

═══════════════════════════════════════════════════════════════════════════════
DEPENDENCY RESOLUTION (CDN-FIRST):
═══════════════════════════════════════════════════════════════════════════════

When building browser-based projects (HTML/CSS/JS), follow these rules:

1. ALWAYS use CDN links for external libraries — never assume npm/node is available.
   Preferred CDNs (in order): unpkg.com, cdn.jsdelivr.net, cdnjs.cloudflare.com, esm.sh
2. For CSS frameworks: <link href="https://cdn.jsdelivr.net/npm/tailwindcss@..."> or similar.
3. For JS libraries: <script src="https://unpkg.com/react@18/umd/react.production.min.js">
4. For ES modules: <script type="module"> import X from 'https://esm.sh/library@version'</script>
5. NEVER generate package.json or run npm/yarn for browser-only projects.
6. NEVER use bare import specifiers (import X from 'lib') in browser JS — always full URLs.

MULTI-FILE PROJECT BEST PRACTICES:
1. ALWAYS split HTML, CSS, and JS into separate files — never inline large CSS/JS blocks.
   - project-name/index.html (link to style.css and script.js)
   - project-name/style.css
   - project-name/script.js
   This is CRITICAL to avoid response truncation.
2. Always create ALL files in a single response — the system executes them as an atomic batch.
3. For the main HTML file, include references to all CSS/JS files via relative paths: <link rel=\"stylesheet\" href=\"style.css\"> and <script src=\"script.js\"></script>.
4. Name the entry point \"index.html\" so the preview engine auto-detects it.
5. If a project needs multiple files, group them in a subfolder: project-name/index.html, project-name/style.css, etc.
6. Keep each file's content under 5000 characters. If content would exceed this, split into additional files.

═══════════════════════════════════════════════════════════════════════════════
EXAMPLE — User: \"Crea carpeta test-octopus con hello.txt\"
═══════════════════════════════════════════════════════════════════════════════

Response:
Creando la carpeta y el archivo dentro.

\`\`\`octopus-action
{
  \"actions\": [
    { \"type\": \"create_dir\", \"path\": \"test-octopus\" },
    { \"type\": \"write_file\", \"path\": \"test-octopus/hello.txt\", \"content\": \"Hola desde Octopus Code Engine!\" }
  ]
}
\`\`\``

// ═══════════════════════════════════════════════════════════════════════════════
// Bridge action types
// ═══════════════════════════════════════════════════════════════════════════════

export type BridgeActionType =
  | 'write_file'
  | 'read_file'
  | 'create_dir'
  | 'read_dir'
  | 'open_path'
  | 'delete_file'
  | 'execute_cmd'

export interface BridgeAction {
  /** Canonical action key — always populated after normalization. */
  action: BridgeActionType
  path?: string
  content?: string
  command?: string
  cwd?: string
}

export interface ParsedCommand {
  raw: string
  action: BridgeAction
  startIdx: number
  endIdx: number
}

const VALID_ACTIONS: ReadonlyArray<BridgeActionType> = [
  'write_file',
  'read_file',
  'create_dir',
  'read_dir',
  'open_path',
  'delete_file',
  'execute_cmd',
]

/** Coerce a parsed JSON node into a list of normalized BridgeAction entries. */
function normalizeActionsFromJson(parsed: unknown): BridgeAction[] {
  const out: BridgeAction[] = []
  if (!parsed || typeof parsed !== 'object') return out

  // Shape A: { actions: [...] }
  const root = parsed as Record<string, unknown>
  if (Array.isArray(root.actions)) {
    for (const item of root.actions) {
      const norm = normalizeSingle(item)
      if (norm) out.push(norm)
    }
    return out
  }

  // Shape B: a single action object
  const norm = normalizeSingle(parsed)
  if (norm) out.push(norm)
  return out
}

function normalizeSingle(node: unknown): BridgeAction | null {
  if (!node || typeof node !== 'object') return null
  const obj = node as Record<string, unknown>
  // accept either "type" or legacy "action"
  const rawKey = (obj.type ?? obj.action) as string | undefined
  if (!rawKey || typeof rawKey !== 'string') return null
  const key = rawKey.trim().toLowerCase().replace(/[\s-]/g, '_') as BridgeActionType
  if (!VALID_ACTIONS.includes(key)) return null
  const result: BridgeAction = { action: key }
  if (typeof obj.path === 'string') result.path = obj.path
  if (typeof obj.content === 'string') result.content = obj.content
  if (typeof obj.command === 'string') result.command = obj.command
  if (typeof obj.cwd === 'string') result.cwd = obj.cwd
  return result
}

// Match: ```octopus-action ... ``` (loose whitespace, optional surrounding text)
const ACTION_BLOCK_REGEX = /```\s*octopus-action\s*\n([\s\S]*?)```/g
// Fallback: bare ```json fence containing { actions: [...] } envelope
const JSON_FENCE_REGEX = /```\s*json\s*\n([\s\S]*?)```/g
// Match truncated fence: opening fence exists but no closing fence (LLM hit token limit)
const TRUNCATED_FENCE_REGEX = /```\s*(?:octopus-action|json)\s*\n([\s\S]+)$/

/**
 * Try to repair truncated JSON by extracting complete action objects.
 * When the LLM hits its token limit, the JSON is cut mid-stream.
 * Instead of trying to close the JSON, we extract each fully-formed action.
 */
function extractCompleteActions(raw: string): BridgeAction[] {
  const results: BridgeAction[] = []

  // Find the "actions" array start
  const actionsIdx = raw.indexOf('"actions"')
  if (actionsIdx < 0) return results
  const bracketIdx = raw.indexOf('[', actionsIdx)
  if (bracketIdx < 0) return results

  // Walk through using brace-counting to extract each complete {...} object in the array
  let i = bracketIdx + 1
  while (i < raw.length) {
    // Skip whitespace and commas
    while (i < raw.length && (raw[i] === ' ' || raw[i] === '\n' || raw[i] === '\r' || raw[i] === '\t' || raw[i] === ',')) i++
    if (i >= raw.length || raw[i] !== '{') break

    // Found start of an object — brace-count to find its end
    let depth = 0
    let inString = false
    let escaped = false
    let objEnd = -1
    for (let j = i; j < raw.length; j++) {
      const ch = raw[j]
      if (escaped) { escaped = false; continue }
      if (ch === '\\' && inString) { escaped = true; continue }
      if (ch === '"' && !escaped) { inString = !inString; continue }
      if (inString) continue
      if (ch === '{') depth++
      else if (ch === '}') { depth--; if (depth === 0) { objEnd = j; break } }
    }

    if (objEnd < 0) {
      // This object is truncated — skip it
      console.log('[parseActions] Skipping truncated action object at position', i)
      break
    }

    const objStr = raw.slice(i, objEnd + 1)
    try {
      const parsed = JSON.parse(objStr)
      const norm = normalizeSingle(parsed)
      if (norm) results.push(norm)
    } catch {
      // Malformed individual object, skip
    }
    i = objEnd + 1
  }

  return results
}

/**
 * Extract bridge actions from an LLM response.
 * Tolerates:
 *  - the canonical ```octopus-action fence (preferred),
 *  - a generic ```json fence whose body contains { actions: [...] },
 *  - a single action object (no actions[] envelope),
 *  - TRUNCATED responses where the closing ``` fence is missing (LLM hit token limit).
 *
 * Returns one ParsedCommand entry per action, in order.
 */
export function parseActions(text: string): ParsedCommand[] {
  const results: ParsedCommand[] = []
  if (!text) return results

  const tryFence = (regex: RegExp) => {
    regex.lastIndex = 0
    let m: RegExpExecArray | null
    while ((m = regex.exec(text)) !== null) {
      const raw = m[1].trim()
      let parsed: unknown
      try {
        parsed = JSON.parse(raw)
      } catch {
        continue
      }
      const actions = normalizeActionsFromJson(parsed)
      for (const a of actions) {
        results.push({
          raw: m[0],
          action: a,
          startIdx: m.index,
          endIdx: m.index + m[0].length,
        })
      }
    }
  }

  tryFence(ACTION_BLOCK_REGEX)

  // Fall back to generic ```json if no octopus-action block found
  if (results.length === 0) {
    tryFence(JSON_FENCE_REGEX)
  }

  // Fall back to raw (unfenced) JSON containing "actions" array.
  // Uses brace-counting to handle large content values with nested braces.
  if (results.length === 0) {
    // Find the position of `"actions"` preceded by a `{`
    const actionsKeyIdx = text.indexOf('"actions"')
    if (actionsKeyIdx > 0) {
      // Walk backwards to find the opening brace
      let openBrace = -1
      for (let i = actionsKeyIdx - 1; i >= 0; i--) {
        if (text[i] === '{') { openBrace = i; break }
        if (text[i] !== ' ' && text[i] !== '\n' && text[i] !== '\r' && text[i] !== '\t') break
      }
      if (openBrace >= 0) {
        // Walk forward with brace-counting to find the matching close
        let depth = 0
        let inString = false
        let escaped = false
        let closeBrace = -1
        for (let i = openBrace; i < text.length; i++) {
          const ch = text[i]
          if (escaped) { escaped = false; continue }
          if (ch === '\\' && inString) { escaped = true; continue }
          if (ch === '"' && !escaped) { inString = !inString; continue }
          if (inString) continue
          if (ch === '{') depth++
          else if (ch === '}') { depth--; if (depth === 0) { closeBrace = i; break } }
        }
        if (closeBrace > openBrace) {
          const raw = text.slice(openBrace, closeBrace + 1)
          try {
            const parsed = JSON.parse(raw)
            const actions = normalizeActionsFromJson(parsed)
            for (const a of actions) {
              results.push({
                raw,
                action: a,
                startIdx: openBrace,
                endIdx: closeBrace + 1,
              })
            }
          } catch {
            console.log('[parseActions] Raw JSON parse failed for unfenced block')
          }
        }
      }
    }
  }

  // TRUNCATION RECOVERY: If no actions found yet, check for truncated fence blocks.
  // This happens when the LLM hits its token limit before writing the closing ``` fence.
  // We extract each fully-formed action object individually.
  if (results.length === 0) {
    const truncMatch = TRUNCATED_FENCE_REGEX.exec(text)
    if (truncMatch) {
      console.log('[parseActions] Detected truncated fence block — attempting action recovery')
      const raw = truncMatch[1].trim()
      // First try: maybe the JSON itself is complete, just missing the fence
      try {
        const parsed = JSON.parse(raw)
        const actions = normalizeActionsFromJson(parsed)
        for (const a of actions) {
          results.push({
            raw: truncMatch[0],
            action: a,
            startIdx: truncMatch.index,
            endIdx: truncMatch.index + truncMatch[0].length,
          })
        }
      } catch {
        // JSON is also truncated — extract individual complete action objects
        const recovered = extractCompleteActions(raw)
        console.log(`[parseActions] Recovered ${recovered.length} complete actions from truncated response`)
        for (const a of recovered) {
          results.push({
            raw: truncMatch[0],
            action: a,
            startIdx: truncMatch.index,
            endIdx: truncMatch.index + truncMatch[0].length,
          })
        }
      }
    }
  }

  console.log(`[parseActions] Found ${results.length} actions from text (${text.length} chars)`)
  return results
}

/**
 * Validate a workspace-relative path. Returns null if safe, error string otherwise.
 */
export function validatePath(path: string | undefined): string | null {
  if (!path || typeof path !== 'string') return 'Path is required'
  const trimmed = path.trim()
  if (!trimmed) return 'Path is empty'
  if (trimmed.startsWith('/') || trimmed.startsWith('\\')) return 'Absolute paths not allowed'
  if (trimmed.startsWith('~')) return 'Home paths not allowed'
  if (/^[a-zA-Z]:/.test(trimmed)) return 'Drive paths not allowed'
  if (trimmed.includes('..')) return 'Path traversal not allowed'
  return null
}

/**
 * Determine if an action requires user confirmation.
 * - read_*, create_dir, write_file → auto-approve (sandbox enforced).
 * - execute_cmd, delete_file       → always confirm.
 */
export function needsConfirmation(action: BridgeAction): boolean {
  if (action.action === 'execute_cmd') return true
  if (action.action === 'delete_file') return true
  return false
}

/** Strip <think>...</think> blocks from LLM output (defense in depth). */
export function stripThinkTags(text: string): string {
  return text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim()
}

/**
 * Strip the octopus-action JSON fence(s) and any generic ```...``` code fences
 * from the displayed assistant text — the UI surfaces results separately.
 * Keeps prose intact.
 */
export function stripActionAndCodeBlocks(text: string): string {
  let out = text.replace(/```\s*octopus-action\s*\n[\s\S]*?```/g, '')
  // Remove any other code fences so the chat stays calm and prose-only.
  out = out.replace(/```[\w-]*\s*\n[\s\S]*?```/g, '')
  return out.trim()
}
