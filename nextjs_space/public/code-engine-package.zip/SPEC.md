# 🐙 Octopus Code Engine — Specification Document

> **Purpose**: This document contains all the specifications needed to rebuild or redesign the Code Engine module. It describes every interface, API contract, database schema, i18n key, and shared dependency. Think of this as the "vehicle spec sheet" — match these interfaces and the new piece will fit perfectly.

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    BROWSER (Next.js Client)                  │
│  page.tsx — Chat UI + Preview Panel + Workspace Panel       │
│                                                              │
│  Communicates via:                                           │
│  • fetch() → REST APIs                                      │
│  • EventSource → SSE streams (chat + command updates)       │
└────────────┬──────────────────────────────────┬─────────────┘
             │                                  │
             ▼                                  ▼
┌────────────────────────┐    ┌─────────────────────────────┐
│  API Routes (Next.js)  │    │  SSE Stream Endpoint        │
│  /api/arms/claude-code/│    │  /api/arms/claude-code/     │
│    chat/   (POST/GET)  │    │    stream/ (GET)            │
│    confirm/ (POST)     │    │  Real-time command updates  │
│    open/    (POST)     │    └─────────────────────────────┘
│    poll/    (GET)      │
│    respond/ (POST)     │
│    workspace/ (GET/POST)│
└────────────┬───────────┘
             │
             ▼
┌────────────────────────┐    ┌─────────────────────────────┐
│  PostgreSQL (Prisma)   │    │  Octopus Bridge (Desktop)   │
│  5 models (see §3)     │◄───│  Polls /poll, posts /respond│
│                        │    │  Auth: x-bridge-token header│
└────────────────────────┘    └─────────────────────────────┘
```

### Data Flow:
1. **User types a message** → `POST /api/arms/claude-code/chat`
2. Chat API streams LLM response via SSE to browser, parses `octopus-action` blocks
3. Creates `BridgeCommand` records in DB (status: `approved` or `pending`)
4. **Bridge (desktop app)** long-polls `GET /api/arms/claude-code/poll` with `x-bridge-token`
5. Bridge executes commands locally (write files, run commands, etc.)
6. Bridge posts results to `POST /api/arms/claude-code/respond`
7. **SSE stream** (`/api/arms/claude-code/stream`) pushes real-time updates to frontend
8. Frontend updates preview panel with results

---

## 2. File Structure (Where Things Go)

```
nextjs_space/
├── app/
│   ├── (dashboard)/dashboard/claude-code/
│   │   └── page.tsx                          ← FRONTEND (2,455 lines)
│   └── api/arms/claude-code/
│       ├── chat/route.ts                     ← LLM chat + action parsing (389 lines)
│       ├── confirm/route.ts                  ← User approves/rejects commands (49 lines)
│       ├── open/route.ts                     ← Direct file/folder open via Bridge (85 lines)
│       ├── poll/route.ts                     ← Bridge long-polling (109 lines)
│       ├── respond/route.ts                  ← Bridge posts results (114 lines)
│       ├── stream/route.ts                   ← SSE real-time updates (189 lines)
│       └── workspace/route.ts                ← Workspace intelligence (253 lines)
└── lib/
    └── claude-code-prompts.ts                ← System prompt + parser (415 lines)
```

---

## 3. Database Schema (Prisma)

These 5 models MUST NOT be renamed or have fields removed. You CAN add new fields.

```prisma
model CodeSession {
  id        String   @id @default(cuid())
  userId    String
  model     String   // OpenRouter model id e.g. "anthropic/claude-sonnet-4.6"
  title     String   @default("New code session")
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  messages  CodeMessage[]
  commands  BridgeCommand[]
  @@index([userId, updatedAt])
}

model CodeMessage {
  id        String   @id @default(cuid())
  sessionId String
  role      String   // "user" | "assistant" | "system"
  content   String   @db.Text
  status    String   @default("completed") // pending | streaming | completed | failed
  error     String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  session   CodeSession @relation(fields: [sessionId], references: [id], onDelete: Cascade)
  commands  BridgeCommand[]
  @@index([sessionId, createdAt])
  @@index([status])
}

model BridgeCommand {
  id                   String   @id @default(cuid())
  sessionId            String
  messageId            String?
  type                 String   // "write_file" | "read_file" | "create_dir" | "read_dir" | "execute_cmd" | "delete_file" | "open_path"
  payload              String   @db.Text     // JSON: { path, content, command, args, ... }
  status               String   @default("pending") // pending | approved | rejected | executing | completed | failed
  result               String?  @db.Text     // JSON encoded result
  error                String?  @db.Text
  streamOutput         String?  @db.Text     // Accumulated stdout/stderr for terminal streaming
  requiresConfirmation Boolean  @default(false)
  createdAt            DateTime @default(now())
  updatedAt            DateTime @updatedAt
  session              CodeSession @relation(fields: [sessionId], references: [id], onDelete: Cascade)
  message              CodeMessage? @relation(fields: [messageId], references: [id], onDelete: SetNull)
  @@index([sessionId, createdAt])
  @@index([status, createdAt])
  @@index([messageId])
}

model WorkspaceIndex {
  id          String   @id @default(cuid())
  userId      String
  fileTree    String   @db.Text      // JSON: full workspace tree snapshot
  fileCount   Int      @default(0)
  totalSize   Int      @default(0)   // bytes
  rootPath    String   @default("")  // workspace root on user's machine
  lastScanAt  DateTime @default(now())
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  @@unique([userId])
  @@index([userId, updatedAt])
}

model FileChangeEvent {
  id          String   @id @default(cuid())
  userId      String
  eventType   String   // "create" | "modify" | "delete" | "rename"
  filePath    String   // relative to workspace
  fileSize    Int?
  isDir       Boolean  @default(false)
  detectedAt  DateTime @default(now())
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  @@index([userId, detectedAt])
  @@index([userId, filePath])
}
```

---

## 4. Shared Dependencies (DO NOT MODIFY)

These are external modules the Code Engine imports. Their signatures are the "connectors".

### 4.1 `@/lib/prisma`
```typescript
import { prisma, withDbRetry } from '@/lib/prisma'
// prisma: PrismaClient instance
// withDbRetry(fn: () => Promise<T>, maxRetries?: number): Promise<T>
//   Retries on P2024, P1001, P1008, P1017 errors
```

### 4.2 `@/lib/auth`
```typescript
import { authOptions } from '@/lib/auth'
import { getServerSession } from 'next-auth'
// Usage: const session = await getServerSession(authOptions)
// session.user.id: string (user's DB id)
```

### 4.3 `@/lib/turbo-llm`
```typescript
import { callLLMStream } from '@/lib/turbo-llm'

// Streaming LLM call (returns raw Response with SSE body)
async function callLLMStream(
  userId: string | null,
  messages: { role: string; content: string | unknown[] }[],
  options?: { model?: string; temperature?: number; maxTokens?: number }
): Promise<Response>
// Response body is an OpenAI-compatible SSE stream:
//   data: {"choices":[{"delta":{"content":"..."}}]}
//   data: [DONE]

// Non-streaming LLM call
async function callLLM(
  userId: string | null,
  messages: { role: string; content: string | unknown[] }[],
  options?: { model?: string; temperature?: number; maxTokens?: number; stream?: boolean; responseFormat?: Record<string, unknown> }
): Promise<{ choices: { message: { content: string; role: string } }[]; model?: string; engine?: string }>
```

### 4.4 `@/lib/turbo-config`
```typescript
import { TURBO_MODELS } from '@/lib/turbo-config'

interface TurboModel {
  id: string           // OpenRouter model id (e.g. "anthropic/claude-sonnet-4.6")
  name: string         // Display name
  provider: string     // Provider name
  providerIcon: string // Emoji
  description: string
  tier: 'fast' | 'pro' | 'ultra'
  contextWindow: string
  supportsVision: boolean
}

const TURBO_MODELS: TurboModel[]  // Array of available models
```

### 4.5 `@/lib/i18n-context` (Client-side)
```typescript
import { useI18n } from '@/lib/i18n-context'

// In component:
const { t } = useI18n()
// t('ce.preview') → returns translated string
// All Code Engine keys start with 'ce.'
// See §6 for full key list
```

### 4.6 `@/lib/claude-code-prompts`
```typescript
// System prompt for the LLM
export const CODE_ENGINE_SYSTEM_PROMPT: string

// Action types
export type BridgeActionType = 'write_file' | 'read_file' | 'create_dir' | 'read_dir' | 'open_path' | 'delete_file' | 'execute_cmd'

export interface BridgeAction {
  action: BridgeActionType
  path?: string
  content?: string
  command?: string
  cwd?: string
}

export interface ParsedCommand {
  raw: string
  action: BridgeAction
  startIdx: number
  endIdx: number
}

// Parse LLM output into bridge commands
export function parseActions(text: string): ParsedCommand[]

// Validate workspace-relative path (returns null if safe, error string if invalid)
export function validatePath(path: string | undefined): string | null

// Check if action needs user confirmation
export function needsConfirmation(action: BridgeAction): boolean

// Remove <think> tags from LLM output
export function stripThinkTags(text: string): string

// Remove action blocks from display text
export function stripActionAndCodeBlocks(text: string): string
```

---

## 5. API Contracts

### 5.1 `POST /api/arms/claude-code/chat`
**Auth**: NextAuth session (cookie)
**Request**:
```json
{ "sessionId?": "string", "model?": "string", "message": "string" }
```
**Response**: SSE stream with events:
- `event: session` → `{ sessionId, messageId, model }`
- `event: delta` → `{ content: "..." }` (streaming LLM tokens)
- `event: commands` → `{ commands: [{ id, type, payload, status, needsConfirm }] }`
- `event: done` → `{ messageId }`
- `event: error` → `{ error, detail }`

### 5.2 `GET /api/arms/claude-code/chat`
**Auth**: NextAuth session
**Query params**:
- `?action=sessions` → `{ sessions: [...] }` (list user sessions)
- `?action=messages&sessionId=X` → `{ session, messages, commands }` (load session)
- `?action=commands&sessionId=X` → `{ commands: [...] }` (commands only)

### 5.3 `DELETE /api/arms/claude-code/chat?sessionId=X`
**Auth**: NextAuth session
Deletes a session and all related messages/commands.

### 5.4 `POST /api/arms/claude-code/confirm`
**Auth**: NextAuth session
**Request**: `{ commandId: string, decision: 'approve' | 'reject' }`
**Response**: `{ ok: true, status: 'approved' | 'rejected' }`

### 5.5 `POST /api/arms/claude-code/open`
**Auth**: NextAuth session
**Request**: `{ sessionId: string, path: string }`
**Response**: `{ ok: true, commandId: string }`

### 5.6 `GET /api/arms/claude-code/poll`
**Auth**: `x-bridge-token` header
Long-polls for up to 25 seconds. Returns approved commands.
**Response**:
```json
{ "pending": true, "commandId": "...", "type": "write_file", "payload": {...}, "batch": [...] }
// or
{ "pending": false }
```

### 5.7 `POST /api/arms/claude-code/respond`
**Auth**: `x-bridge-token` header
**Request** (final result):
```json
{ "commandId": "...", "status": "completed" | "failed", "result?": {...}, "error?": "string" }
```
**Request** (stream chunk for terminal output):
```json
{ "commandId": "...", "action": "stream", "chunk": "stdout text..." }
```

### 5.8 `GET /api/arms/claude-code/stream?sessionId=X`
**Auth**: NextAuth session
SSE stream that pushes real-time command updates:
- `event: connected` → `{ sessionId }`
- `event: command_new` → `{ id, type, payload, status, requiresConfirmation, createdAt }`
- `event: command_update` → `{ id, status, result, error }`
- `event: stream_output` → `{ id, delta, total }` (terminal streaming)
- `event: heartbeat` → `{ ts }`

### 5.9 `POST /api/arms/claude-code/workspace`
**Auth**: `x-bridge-token` header
**Request** (full scan): `{ action: 'full_scan', fileTree: [...], fileCount, totalSize, rootPath }`
**Request** (changes): `{ action: 'file_changes', changes: [{ eventType, filePath, fileSize?, isDir? }] }`

### 5.10 `GET /api/arms/claude-code/workspace`
**Auth**: NextAuth session
- `?action=index` → workspace index with file tree
- `?action=changes&since=ISO` → recent file change events
- `?action=context` → compact text summary for LLM injection

---

## 6. i18n Keys (ALL keys prefixed with `ce.`)

The frontend uses `t('ce.key_name')` for all text. Both Spanish (ES) and English (EN) versions exist.
You MUST use these exact keys. You CAN add new keys.

```
ce.header                 → "Code Engine · Local Bridge" / "Code Engine · Bridge Local"
ce.title_empty            → "What shall we build?" / "¿Qué vamos a construir?"
ce.placeholder            → "Ask Octopus to create or run something..."
ce.ask                    → "Ask"
ce.sandbox_notice         → "Sandbox active: only files inside your workspace are modified."
ce.sessions               → "Sessions" / "Sesiones"
ce.new_session            → "New session" / "Nueva sesión"
ce.model                  → "Model" / "Modelo"
ce.new                    → "New" / "Nueva"
ce.preview                → "Preview"
ce.preview_empty          → "Results for each action will appear here."
ce.preview_refresh        → "Refresh preview"
ce.preview_open_browser   → "Open in browser"
ce.preview_expand         → "Expand preview"
ce.preview_collapse       → "Collapse preview"
ce.preview_updating       → "Updating..."
ce.status_live            → "Applying changes live..."
ce.status_idle            → "Files are being written to your PC."
ce.thinking               → "Analyzing structure..."
ce.error_action           → "There was a problem executing the action."
ce.retry                  → "Retry"
ce.show_details           → "Show conversation details"
ce.hide_details           → "Hide details"
ce.role_user              → "You" / "Tú"
ce.role_assistant          → "Octopus"
ce.needs_approval         → "Needs your approval"
ce.approve                → "Approve" / "Aprobar"
ce.reject                 → "Reject" / "Rechazar"
ce.action_write           → "Writing file"
ce.action_write_done      → "File created"
ce.action_read            → "Reading file"
ce.action_read_done       → "File read"
ce.action_mkdir           → "Creating folder"
ce.action_mkdir_done      → "Folder created"
ce.action_ls              → "Listing folder"
ce.action_ls_done         → "Folder listed"
ce.action_open            → "Opening on your PC"
ce.action_open_done       → "Opened on your PC"
ce.action_delete          → "Deleting"
ce.action_delete_done     → "Deleted"
ce.action_exec            → "Running command"
ce.action_exec_done       → "Command executed"
ce.chip_open_file         → "Open file"
ce.chip_open_folder       → "Open folder"
ce.chip_preview           → "Preview"
ce.chip_open_browser      → "Open in browser"
ce.project_created        → "Project created"
ce.preview_title          → "Preview"
ce.preview_cancelled      → "Action cancelled"
ce.preview_failed         → "Could not complete"
ce.preview_folder_created → "Folder created"
ce.preview_deleted        → "Deleted"
ce.preview_cmd_result     → "Command result"
ce.preview_ready          → "Ready"
ce.view_code              → "View code"
ce.view_render            → "Rendered" / "Vista"
ce.pending_approval       → "Waiting for your approval"
ce.executing              → "Applying changes on your PC..."
ce.suggestion_1           → "Create a test-octopus folder with hello.txt"
ce.suggestion_2           → "List files in my workspace"
ce.suggestion_3           → "Create an index.html with a button and title"
ce.shift_enter_hint       → "Shift+Enter for new line"
ce.error_generic          → "There was a problem executing the action."
ce.error_network          → "Network error"
ce.bridge_offline_title   → "Bridge not connected"
ce.bridge_offline_desc    → "Code Engine needs the Octopus Bridge running on your PC."
ce.install_bridge         → "Install Bridge"
ce.confirm_delete         → "Delete this conversation?"
ce.code_hidden            → "[code hidden]"
ce.no_sessions            → "No sessions yet."
ce.terminal_live          → "Live terminal"
ce.ws_not_indexed         → "Workspace not indexed"
ce.ws_not_indexed_hint    → "Reinstall the Bridge to activate context intelligence."
ce.ws_context_active      → "Context active"
ce.ws_files               → "files"
ce.ws_recent_changes      → "Recent external changes"
ce.ws_file_tree           → "File tree"
ce.ws_last_scan           → "Last scan"
ce.project_preview        → "Project preview"
ce.project_no_html        → "No HTML file found in this session."
ce.project_combined       → "HTML + CSS + JS combined"
ce.project_view           → "Project view"
ce.single_file            → "Single file"
ce.batch_progress         → "Batch in progress"
ce.batch_failed           → "Action failed — remaining skipped"
ce.batch_skipped          → "Skipped"
ce.cached                 → "Cached"
ce.terminal_output        → "Terminal output"
ce.phase_progress         → "Progress"
ce.phase_analyzing        → "Analyzing"
ce.phase_executing        → "Executing"
ce.phase_completed        → "Completed"
ce.phase_failed           → "Execution error"
ce.phase_files            → "actions"
ce.offline_mode           → "Offline mode"
ce.resync_pending         → "Re-sync pending"
ce.resync_complete        → "Re-sync complete"
```

---

## 7. Design Guidelines

### Philosophy
- **"Peace, not complexity"** — Apple/Codex aesthetic
- White minimalist, soft gray accents
- No clutter, no heavy borders
- Generous whitespace

### Current Layout (3-column)
```
┌──────┬──────────────────────────────┬───────────────┐
│ Side │  LEFT: Chat + Input          │ RIGHT: Preview│
│ bar  │  (sessions panel hidden by   │ + Workspace   │
│      │   default, toggle via icon)  │ (380px)       │
│      │                              │               │
│      │  Activity feed (not bubbles) │ Tab: Preview  │
│      │  Capsule input at bottom     │ Tab: Workspace│
│      │                              │               │
└──────┴──────────────────────────────┴───────────────┘
```

### Color Palette (Tailwind)
- Background: `white`, `zinc-50/50`
- Text: `zinc-900`, `zinc-700`, `zinc-500`, `zinc-400`
- Accents: `amber-400` (executing), `emerald-500` (indexed), `rose-500` (errors)
- Borders: `zinc-100`, `zinc-200`
- Input: capsule style with `rounded-2xl`

### Tech Stack
- React 18 with hooks
- Tailwind CSS (no CSS modules)
- Framer Motion for animations
- Lucide React for icons
- EventSource for SSE
- No external UI library (custom components only)

### Icons Used
```
Send, Loader2, Plus, Trash2, AlertTriangle, RefreshCw, Folder,
Settings, Check, ChevronDown, ChevronUp, Shield, Sparkles,
Eye, FolderTree, FileText, FolderOpen, Zap, Maximize2,
Minimize2, ExternalLink, RotateCw, X
```

---

## 8. Bridge Status Detection

The frontend detects Bridge status by polling `/api/arms/ollama/status`.
The relevant response shape:
```json
{
  "online": true | false,
  "lastSeenAt": "ISO date string",
  "models": [...]
}
```
The component polls this every 15 seconds and shows a "Bridge Offline" overlay when `online === false`.

---

## 9. Preview System (Key Area for Redesign)

Current architecture:
- `PreviewPanel` component renders file content based on type (HTML → iframe, CSS/JS → code view, text → plain)
- `ProjectPreview` component combines HTML+CSS+JS from multiple commands into a single iframe
- `WrittenPreview` handles individual file rendering
- **Zen Mode**: Right panel expands to fullscreen via CSS (`fixed inset-0 z-[9999]`) — no portal, no second iframe
- ESC key closes expanded mode

### Preview Rules:
1. HTML files render in a sandboxed iframe (`allow-scripts allow-same-origin allow-modals allow-forms allow-popups`)
2. CSS/JS files show syntax-highlighted code with toggle to see rendered view
3. Project mode combines the latest HTML + all CSS + all JS files into one combined iframe
4. Preview auto-selects the last `write_file` command with previewable content
5. Refresh button increments a key to force iframe reload

---

## 10. State Management

All state is managed via React hooks (no Redux, no Zustand).

Key state variables in page.tsx:
```typescript
// Sessions
sessions, currentSessionId, messages, commands

// UI
rightTab: 'preview' | 'workspace'
previewExpanded: boolean
projectPreview: boolean  
previewRefreshKey: number
showSessions: boolean
showConvoDetail: boolean

// Input
input: string
sending: boolean

// Bridge
bridgeStatus: { online: boolean; lastSeenAt?: string }

// Workspace
workspace: { indexed: boolean; fileCount: number; totalSize: number; rootPath: string; ... }
recentChanges: FileChangeEvent[]

// Model selection
selectedModel: string

// Streaming
isThinking: boolean
streamContent: string
```

---

## 11. Installation Instructions

When Antigravity returns the redesigned files:

1. Place `page.tsx` → `app/(dashboard)/dashboard/claude-code/page.tsx`
2. Place API routes → `app/api/arms/claude-code/{name}/route.ts`
3. Place lib → `lib/claude-code-prompts.ts`
4. Run: `cd nextjs_space && npx tsc --noEmit` (TypeScript check)
5. Run: `yarn run build` (verify build passes)
6. Deploy

**Rules**:
- DO NOT rename API route paths (Bridge depends on them)
- DO NOT remove or rename Prisma model fields (DB has data)
- DO NOT change the `x-bridge-token` auth mechanism
- CAN add new fields, new API parameters, new i18n keys
- CAN completely redesign the frontend UI
- CAN add new features to the API routes
