import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma, withDbRetry } from '@/lib/prisma'
import { callLLMStream } from '@/lib/turbo-llm'
import {
  CODE_ENGINE_SYSTEM_PROMPT,
  parseActions,
  validatePath,
  needsConfirmation,
  stripThinkTags,
} from '@/lib/claude-code-prompts'

export const dynamic = 'force-dynamic'
export const maxDuration = 300

// Default model (user can override per-session)
const DEFAULT_MODEL = 'anthropic/claude-sonnet-4.6'

// ═══════════════════════════════════════════════════════════════════════════════
// POST /api/arms/claude-code/chat — Send user message, stream Claude response via SSE
// ═══════════════════════════════════════════════════════════════════════════════
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const userId = session.user.id

  let body: { sessionId?: string; model?: string; message: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  const { sessionId, message } = body
  const model = body.model || DEFAULT_MODEL

  if (!message || typeof message !== 'string' || !message.trim()) {
    return NextResponse.json({ error: 'message is required' }, { status: 400 })
  }

  // Verify Bridge is online (ApiKey + recent armConnection report)
  const arm = await prisma.armConnection.findFirst({
    where: { userId, armType: 'ollama' },
  })
  if (!arm) {
    return NextResponse.json({
      error: 'no_bridge',
      message: 'Bridge not detected. Install and run the Octopus Bridge first.',
    }, { status: 400 })
  }
  const creds = JSON.parse(arm.credentials || '{}')
  const lastSeen = creds.lastSeenAt ? new Date(creds.lastSeenAt).getTime() : 0
  if (Date.now() - lastSeen > 3 * 60 * 1000) {
    return NextResponse.json({
      error: 'bridge_offline',
      message: 'Bridge has not reported in the last 3 minutes. Is it running?',
    }, { status: 400 })
  }

  // Create or reuse session
  let chatSession = sessionId
    ? await prisma.codeSession.findFirst({ where: { id: sessionId, userId } })
    : null

  if (!chatSession) {
    const title = message.length > 50 ? message.slice(0, 47) + '...' : message
    chatSession = await prisma.codeSession.create({
      data: { userId, model, title },
    })
    // Inject system prompt as first message
    await prisma.codeMessage.create({
      data: {
        sessionId: chatSession.id,
        role: 'system',
        content: CODE_ENGINE_SYSTEM_PROMPT,
        status: 'completed',
      },
    })
  }

  const sid = chatSession.id

  // Save user message
  await prisma.codeMessage.create({
    data: { sessionId: sid, role: 'user', content: message, status: 'completed' },
  })

  // Create the assistant placeholder (will be filled as stream completes)
  const assistantMsg = await prisma.codeMessage.create({
    data: { sessionId: sid, role: 'assistant', content: '', status: 'streaming' },
  })

  // Build full message history for LLM
  const allMsgs = await prisma.codeMessage.findMany({
    where: { sessionId: sid, status: 'completed' },
    orderBy: { createdAt: 'asc' },
    select: { role: true, content: true },
  })

  // Inject workspace context if available (before user messages)
  let workspaceContext = ''
  try {
    const wsIndex = await prisma.workspaceIndex.findUnique({ where: { userId } })
    if (wsIndex && wsIndex.fileTree) {
      const tree: Array<{ path: string; isDir: boolean; size: number }> = JSON.parse(wsIndex.fileTree)
      const dirs = tree.filter(f => f.isDir).map(f => f.path)
      const files = tree.filter(f => !f.isDir)
      const extGroups: Record<string, number> = {}
      for (const f of files) {
        const ext = f.path.split('.').pop()?.toLowerCase() || 'other'
        extGroups[ext] = (extGroups[ext] || 0) + 1
      }
      // Recent external changes
      const recentChanges = await prisma.fileChangeEvent.findMany({
        where: { userId, detectedAt: { gte: new Date(Date.now() - 30 * 60 * 1000) } },
        orderBy: { detectedAt: 'desc' },
        take: 15,
      })

      const lines = [
        `\n[WORKSPACE CONTEXT — auto-injected, do NOT repeat to user]`,
        `Root: ${wsIndex.rootPath} | ${wsIndex.fileCount} files | ${formatBytes(wsIndex.totalSize)}`,
        `Scanned: ${wsIndex.lastScanAt.toISOString()}`,
        dirs.length > 0 ? `Dirs: ${dirs.slice(0, 25).join(', ')}` : '',
        files.length > 0 ? `Files: ${files.slice(0, 40).map(f => f.path).join(', ')}` : '',
        `Extensions: ${Object.entries(extGroups).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `.${k}:${v}`).join(' ')}`,
      ]
      if (recentChanges.length > 0) {
        lines.push(`Recent external changes: ${recentChanges.map(c => `${c.eventType}:${c.filePath}`).join(', ')}`)
      }
      workspaceContext = lines.filter(Boolean).join('\n')
    }
  } catch { /* workspace context is non-critical */ }

  const llmMessages = allMsgs.map(m => {
    // Append workspace context to the system message
    if (m.role === 'system' && workspaceContext) {
      return { role: m.role, content: m.content + '\n' + workspaceContext }
    }
    return { role: m.role, content: m.content }
  })

  // Update session timestamp and model
  await prisma.codeSession.update({
    where: { id: sid },
    data: { model, updatedAt: new Date() },
  })

  // Build SSE response
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    async start(controller) {
      const send = (event: string, data: Record<string, unknown>) => {
        try {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
        } catch {}
      }

      send('session', { sessionId: sid, messageId: assistantMsg.id, model })

      let fullContent = ''
      try {
        const llmRes = await callLLMStream(userId, llmMessages, {
          model,
          temperature: 0.3,
          maxTokens: 16000,
        })

        if (!llmRes.ok || !llmRes.body) {
          const errText = await llmRes.text().catch(() => '')
          send('error', { error: 'llm_failed', detail: errText.substring(0, 300) })
          await prisma.codeMessage.update({
            where: { id: assistantMsg.id },
            data: { status: 'failed', error: 'LLM stream failed' },
          })
          controller.close()
          return
        }

        // Parse OpenAI-style SSE stream
        const reader = llmRes.body.getReader()
        const decoder = new TextDecoder()
        let buffer = ''
        let lastDbFlush = Date.now()

        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })
          const lines = buffer.split('\n')
          buffer = lines.pop() || ''
          for (const line of lines) {
            const trimmed = line.trim()
            if (!trimmed.startsWith('data:')) continue
            const data = trimmed.substring(5).trim()
            if (!data || data === '[DONE]') continue
            try {
              const json = JSON.parse(data)
              const delta = json.choices?.[0]?.delta?.content
              if (delta) {
                fullContent += delta
                send('delta', { content: delta })
                // Flush to DB every 1.5s
                if (Date.now() - lastDbFlush > 1500) {
                  lastDbFlush = Date.now()
                  prisma.codeMessage
                    .update({
                      where: { id: assistantMsg.id },
                      data: { content: stripThinkTags(fullContent) },
                    })
                    .catch(() => {})
                }
              }
            } catch {}
          }
        }

        // Final cleanup of LLM output
        const cleanContent = stripThinkTags(fullContent)

        // Parse actions from the final content
        const actions = parseActions(cleanContent)
        console.log(`[CodeEngine] Parsed ${actions.length} actions from LLM response (${cleanContent.length} chars)`)
        const createdCommands: { id: string; type: string; payload: Record<string, unknown>; status: string; needsConfirm: boolean }[] = []

        for (const action of actions) {
          // Validate path for fs operations
          const a = action.action
          let invalid: string | null = null
          if (a.action !== 'execute_cmd') {
            // open_path with empty path = open workspace root, allowed
            if (a.action === 'open_path' && (!a.path || a.path === '')) {
              invalid = null
            } else {
              invalid = validatePath(a.path)
            }
          }
          if (invalid && a.action !== 'execute_cmd') {
            console.log(`[CodeEngine] Skipping invalid action: ${a.action} path="${a.path}" — ${invalid}`)
            send('command_invalid', { error: invalid, action: a })
            continue
          }
          const requiresConfirm = needsConfirmation(a)
          try {
            const cmd = await withDbRetry(() =>
              prisma.bridgeCommand.create({
                data: {
                  sessionId: sid,
                  messageId: assistantMsg.id,
                  type: a.action,
                  payload: JSON.stringify(a),
                  status: requiresConfirm ? 'pending' : 'approved',
                  requiresConfirmation: requiresConfirm,
                },
              }),
            )
            createdCommands.push({
              id: cmd.id,
              type: a.action,
              payload: a as unknown as Record<string, unknown>,
              status: requiresConfirm ? 'pending' : 'approved',
              needsConfirm: requiresConfirm,
            })
            console.log(`[CodeEngine] Created command: ${a.action} id=${cmd.id}`)
          } catch (dbErr) {
            console.error(`[CodeEngine] Failed to create command ${a.action}:`, dbErr)
            send('command_invalid', { error: `DB error creating command: ${a.action}`, action: a })
          }
        }

        // Store final assistant message
        await withDbRetry(() =>
          prisma.codeMessage.update({
            where: { id: assistantMsg.id },
            data: {
              content: cleanContent,
              status: 'completed',
            },
          }),
        )

        send('commands', { commands: createdCommands })
        send('done', { messageId: assistantMsg.id })
        controller.close()
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error'
        send('error', { error: 'stream_error', detail: msg })
        await prisma.codeMessage
          .update({
            where: { id: assistantMsg.id },
            data: { status: 'failed', error: msg.substring(0, 500) },
          })
          .catch(() => {})
        try { controller.close() } catch {}
      }
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
}

// ═══════════════════════════════════════════════════════════════════════════════
// GET /api/arms/claude-code/chat
// ?action=sessions  -> list sessions
// ?action=messages&sessionId=X  -> get messages + commands
// ?action=session&sessionId=X   -> get single session metadata
// ═══════════════════════════════════════════════════════════════════════════════
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const userId = session.user.id
  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action') || 'sessions'

  if (action === 'sessions') {
    const sessions = await prisma.codeSession.findMany({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
      take: 50,
      include: { _count: { select: { messages: true, commands: true } } },
    })
    return NextResponse.json({ sessions })
  }

  if (action === 'messages') {
    const sessionId = searchParams.get('sessionId')
    if (!sessionId) return NextResponse.json({ error: 'sessionId required' }, { status: 400 })
    const cs = await prisma.codeSession.findFirst({ where: { id: sessionId, userId } })
    if (!cs) return NextResponse.json({ error: 'Session not found' }, { status: 404 })
    const messages = await prisma.codeMessage.findMany({
      where: { sessionId, role: { not: 'system' } },
      orderBy: { createdAt: 'asc' },
    })
    const commands = await prisma.bridgeCommand.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json({ session: cs, messages, commands })
  }

  if (action === 'commands') {
    const sessionId = searchParams.get('sessionId')
    if (!sessionId) return NextResponse.json({ error: 'sessionId required' }, { status: 400 })
    const cs = await prisma.codeSession.findFirst({ where: { id: sessionId, userId } })
    if (!cs) return NextResponse.json({ error: 'Session not found' }, { status: 404 })
    const commands = await prisma.bridgeCommand.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json({ commands })
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
}

// ═══════════════════════════════════════════════════════════════════════════════
// DELETE — Remove a session
// ═══════════════════════════════════════════════════════════════════════════════
export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const { searchParams } = new URL(req.url)
  const sessionId = searchParams.get('sessionId')
  if (!sessionId) return NextResponse.json({ error: 'sessionId required' }, { status: 400 })
  const cs = await prisma.codeSession.findFirst({ where: { id: sessionId, userId: session.user.id } })
  if (!cs) return NextResponse.json({ error: 'Session not found' }, { status: 404 })
  await prisma.codeSession.delete({ where: { id: sessionId } })
  return NextResponse.json({ ok: true })
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)}KB`
  return `${(bytes / 1048576).toFixed(1)}MB`
}
